<?php
$user_db="root";
$motpasse="usbw";
$host="localhost";
$basebd="gestion";
mysql_connect($host,$user_db,$motpasse);
mysql_select_db($basebd);
?>