<?php

include('verification.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<script type="text/javascript">

function verifForm(f)
{
   var ageOk = verifAge(f.quantitedispo);
   
   if(ageOk)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}

function verifAge(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 500)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}

function verifAge2(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}


function verifAge3(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}
</script>

</head>

<body>
<?php include('menu2.php'); ?>

<center>
<br />
<div id="global">

<br /><br />
<b>PAGE DES APPROVISIONNEMENTS</b>
<br />

<form action="approvisionner1.php" method="post" onsubmit="return verifForm(this)">
	<table cellpadding="1" cellspacing="1" border="1">
	<tr><td>DESIGNATION</td><td>VALEUR ASSOCIEE</td>
	</tr><br>
<tr>
	<td><label id="">NOM </label></td>
	<td><select name="nom">

<?php


$query=mysql_query("SELECT * FROM produit");
$data=mysql_num_rows($query);

for($i=0;$i<$data;$i++)
  {
  $nom=mysql_result($query,$i,"nom");
  
 echo' <option>'.$nom.' </option>';
	
  }
?>

	
	</select></td>
	</tr>
	<tr>
    <td><label id="">QUANTITE  </label></td>
    <td><input type="text" name="quantitedispo" onblur="verifAge(this)"></td>
	</tr>
	<tr>
   <td> </td> <td><input type="submit" name="Envoyer" value="Approvisionner"></td>
   </tr>
   </table>
     </form>
	 <br /><br />
	 
	 <?php
	 //selection de tous les produits entr�s
	 $query=mysql_query("SELECT * FROM approvisionnement WHERE statut='0' ")or die('Erreur sql:'.mysql_error());
	 $nombre=mysql_num_rows($query);
	 if($nombre==0){
	 echo'<br><br><b>AUCUN APPROVISIONNEMENT EN COURS </b><br><br>';}
	 else {
	 
	 ?>
	 
	 <table>
	 <tr>
	 <td>ID</td>
	 <td>NOM ARTICLE</td>
	 <td>Quantite Approvisionnee</td>
	 </tr>
	 
	 <?php
	 
	 for($p=0;$p<$nombre;$p++) {
	 $id=mysql_result($query,$p,"id");
	 $nomproduit=mysql_result($query,$p,"nom");
	 $quantite=mysql_result($query,$p,"quantite");
	 echo'<tr>';
	 echo'<td>'.$id.'</td>';
	 echo'<td>'.$nomproduit.'</td>';
	 echo'<td>'.$quantite.'</td>';
	 echo'</tr>';
	 //echo'<tr>';
	 //echo'<td><input type="submit" name="Modifier" value="Modifier" /></td>';
	 //echo'</tr>';
	 }
	 
	 ?>
	 
	 </table>
	 
	<br /><br /><b>POUR FINIR L'APPROVISIONNEMENT,CLIQUEZ <a href="fin_approvisionnement.php">ICI</a></b><br /><br />
	 </center>
	 <br />
	 	 <?php 
		 }
		 echo'</div>';
		 include('footer.php'); ?>

	 
	 </body>
	 </html>