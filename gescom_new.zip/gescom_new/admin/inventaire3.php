<?php
session_start();
include('verification.php');
//$_GET['page']='';
?>

<?php
include('menu2.php');
echo'<br><br>';

?>
<center>
<div id="global">
<br><br>
<?php

echo'<br><br><b>VOULEZ VOUS VRAIMENT CLOTURER L\'INVENTAIRE?SI OUI,RESTITUER LA PERIODE DE REFERENCE</b><br><br><br>';
echo'<legend>ACTION IRREVERSIBLE.POUR CONTINUER,APPUYER SUR FERMER INVENTAIRE</legend>';
echo'<form action="inventaire4.php" method="post">';
echo'<label>PERIODE ALLANT DE</label>&nbsp;<div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" id="from" name="date1"  />&nbsp;<label>A</label>&nbsp;<input type="text" id="to" name="date2"  /></div></div><br><br>';
echo'<input type="submit" name="Envoyer" value="Fermer Inventaire" />&nbsp;&nbsp;<input type="submit" name="Annuler" value="Ne rien faire"><br><br> ';

echo'</center>';

echo'</form>';
 
?>
<br /><br />
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>PAGE INVENTAIRE</title>

<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>

<body>





<center>
                          


<?php


//if(!empty($_GET['page']))
//include($_GET['page']);
?>

</center>
</center>


</center>
<br />
<?php include('footer.php'); ?>