<?php
mysql_connect("localhost", "root", "");
mysql_select_db("gestion");
$pseudo = mysql_real_escape_string(htmlspecialchars($_POST['pseudo']));
$passe = mysql_real_escape_string(htmlspecialchars($_POST['passe']));
// Je crypte $passe avec la fonction "sha1".
$passe = sha1($passe);
$nbre = mysql_query("SELECT COUNT(*) AS exist FROM connexion WHERE pseudo='$pseudo'");
$donnees = mysql_fetch_array($nbre);
if($donnees['exist'] != 0) // Si le pseudo existe.
{
$quete = mysql_query("SELECT * FROM connexion WHERE pseudo='$pseudo'");
$infos = mysql_fetch_array($quete);
if($passe == $infos['passe'])
{
// C'est ici que je mets le code servant à effectuer la connexion, car le mot de passe est bon.
//on dirige vers la page des utilisateurs
$_SESSION['pseudo']=$pseudo;
header('Location:membres/index.php');
}
else // Si le couple pseudo/ mot de passe n'est pas bon.
{
echo 'Vous n\'avez pas rentré les bons identifiants';
}
}
?>﻿
<?php

echo '<form method="post">';
echo'<label>Pseudo: <input type="text" name="pseudo"/></label><br/>';
echo '<label>Mot de passe: <input type="password" name="passe"/></label><br/>';

echo '<input type="submit" value="M\'inscrire"/>';
echo'</form>';

?>

<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>

</body>
</html>