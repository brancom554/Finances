<?php
session_start();
if(!isset($_SESSION['pseudo']))
{
echo 'Vous n\'êtes pas connecté au site. Vous ne pouvez donc pas venir sur cette page.';
exit;
}
?>﻿