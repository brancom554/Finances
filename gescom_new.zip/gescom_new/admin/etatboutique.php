<?php

include('verification.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>


</head>

<body>
<?php include('menu2.php'); ?>

<center>
<br />
<div id="global">
<br /><br />
<b>ETAT DE LA BOUTIQUE EN TEMPS REEL</b><br /><br />
<table>
<tr>
<td>ARTICLE</td><td>QUANTITE DISPONIBLE</td><td>PRIX UNITAIRE</td><td>SOMME ATTENDUE</td><td>BENEFICE</td>
</tr>
<?php
$vente_total=0;
$benefice_total1=0;

$req=mysql_query("SELECT * FROM produit") or die('Erreur sql:'.mysql_error());
$compteur=mysql_num_rows($req);
for($d=0;$d<$compteur;$d++) {
$nom=mysql_result($req,$d,"nom");
$quantitedispo=mysql_result($req,$d,"quantitedispo");
$prixunitaire=mysql_result($req,$d,"prixvente");
$benefice=mysql_result($req,$d,"benefice");
$somme= $quantitedispo * $prixunitaire;
$benefice_total= $quantitedispo * $benefice;
$vente_total=$vente_total + $somme;
$benefice_total1= $benefice_total1 + $benefice_total;
echo'<tr>';
echo'<td>'.$nom.'</td>';
echo'<td>'.$quantitedispo.'</td>';
echo'<td>'.$prixunitaire.'</td>';
echo'<td>'.$somme.'</td>';
echo'<td>'.$benefice_total.'</td>';
echo'</tr>';


      }
?>
<tr>
<td></td><td>VENTES TOTALES ATTENDUES</td><td><?php echo $vente_total; ?></td>
</tr>
<tr>
<td></td><td>BENEFICE TOTAL ATTENDU</td><td><?php echo $benefice_total1; ?></td>
</tr>
</table>
<br /><br />
	 
	 
	 
	 
	 
		 </div>
		 
	<?php	 include('footer.php'); ?>

	 
	 </body>
	 </html>