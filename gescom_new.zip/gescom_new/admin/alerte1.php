
<style type="text/css">
#alerte{
width:1100px;
height:auto;
background-color:#3399CC;
-webkit-border-radius: 4px 4px 6px 6px;

 border-radius: 4px 4px 6px 6px;
   -webkit-box-shadow: inset 15px 2px 3px 3px #2020a6; box-shadow: inset 3px 2px 3px 3px #2020a6;

}
</style>

<center>
<div id="alerte">
<?php


				
				$query=mysql_query("SELECT COUNT(nom) as nombre FROM produit where quantitedispo<6 ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	
					
              
					
					else {
  $n =mysql_fetch_array($query);
 $compte=$n["nombre"];
 if($compte!=0)
 echo '<br><b>VOUS AVEZ '.$compte .'&nbsp;&nbsp;NOTIFICATIONS EN COURS. VEUILLEZ CLIQUER <a href="alerte.php">ICI</a></b><br>';
 else
 echo'<br><b>AUCUNE NOTIFICATIONS EN COURS</b><br>';
									  
							}
						


?>

</div>
</center>