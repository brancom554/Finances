1.	images � folder have icons and other pictures used in the creation of datepicker.
2.	jquery-ui.css � is the default jQuery UI CSS file.
3.	demos.css � has the code to style the jQuery datepicker.
4.	jquery.ui.core.js, jquery.ui.widget.js, jquery-1.5.1.js are the default jQuery JavaScript files.
5.	jquery.ui.datepicker.js - is the JavaScript file to implement datepicker.
6.	demo-datepicker.html � has the code of default datepicker.
7.	demo-datepicker-inline.html � has the code to display inline datepicker.
8.	demo-datepicker-menu.html � has the code to display inline datepicker with menus of year and month.
9.	demo-datepicker-restrict.html � has the code to display datepicker with restrict range.
10.	demo-datepicker-alternate-field.html � has the demo to populate another text field on selecting a date.
11.	demo-datepicker-buttons.html � has the demo to show buttons on the datepicker.
12.	demo-datepicker-other-months.html � has the demo to show datepicker, which displays days in other months in the current month.
13.	demo-datepicker-show-weeks.html � has the demo to show the datepicker displaying weeks of the year.
14.	demo-datepicker-multiple-months.html � contains the code to implement the datepicker with multiple months.
15.	demo-datepicker-date-range.html � has the code to implement the datepicker within a date range.

