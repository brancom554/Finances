<?php
//include('stat.php');

include('verification.php');
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<script type="text/javascript">

function verifForm(f)
{
   var ageOk = verifAge(f.quantitedispo);
   var age2Ok = verifAge2(f.prixachat);
   var age3Ok = verifAge3(f.prixvente);
      var age4Ok = verifAge4(f.nom);

   
   if(ageOk && age2Ok && age3Ok)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}

function verifAge(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 500)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}

function verifAge2(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}


function verifAge3(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}

function verifAge4(champ)
{

   var age = champ.value;
   if(age=='')
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}
</script>

</head>

<body>
<?php include('menu2.php') ; ?>
<br />
<center>
<div id="global">
<br />
<b>PAGE D'AJOUT DE PRODUITS</b>
<br />
<form action="ajout_produit1.php" method="post" onsubmit="return verifForm(this)">
	<table cellpadding="1" cellspacing="1" border="1">
	<tr><td>DESIGNATION</td><td>VALEUR ASSOCIEE</td>
	</tr><br>
	<tr>
	<td><label id="">REF </label></td>
	<td><input type="text" name="ref"></td>
	</tr><br>
	<tr>
	<td><label id="">NOM </label></td>
	<td><input type="text" name="nom" onblur="verifAge4(this)"></td>
	</tr>
	<tr>
    <td><label id="">QUANTITE  </label></td>
    <td><input type="text" name="quantitedispo" onblur="verifAge(this)"></td>
	</tr>
	<tr>
    <td><label id="">Prix Achat </label></td>
    <td><input type="text" name="prixachat" onblur="verifAge2(this)"></td>
	</tr>
	<tr>
    <td><label id="">Prix Vente </label></td>
    <td><input type="text" name="prixvente" onblur="verifAge3(this)"></td>
	</tr>
	
	<tr>
   <td> </td> <td><input type="submit" name="Envoyer" value="Envoyer"></td>
   </tr>
   </table>
     </form><br /><br />

</div></center>
<br />
<?php include('footer.php')  ; ?>
</body>
</html>
