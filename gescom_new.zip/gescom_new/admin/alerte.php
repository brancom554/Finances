
<style type="text/css">
#alerte{
width:1100px;
height:auto;
background-color:#3399CC;
-webkit-border-radius: 4px 4px 6px 6px;

 border-radius: 4px 4px 6px 6px;
   -webkit-box-shadow: inset 15px 2px 3px 3px #2020a6; box-shadow: inset 3px 2px 3px 3px #2020a6;

}
</style>

<center>
<div id="alerte">
<br>
<a href="vendre.php"><b>PAGE PRECEDENTE</b></a><br><br>
<?php
include("../config.php");

				
				$query=mysql_query("SELECT * FROM produit ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	
					
              
					
					else {
  $n =mysql_num_rows($query);
 for($i=0;$i<$n;$i++) {
 
  //$id=mysql_result($query,$i,"id"); 
   $nom=mysql_result($query,$i,"nom"); 
   $quantiteproduit=mysql_result($query,$i,"quantitedispo"); 
   $benefice=mysql_result($query,$i,"benefice"); 
 $prixvente=mysql_result($query,$i,"prixvente"); 
 //$date=mysql_result($query,$i,"datevente");
 
 
					
	if($quantiteproduit <= 5){
	//header('Location:alerte1.php'); 
	
	echo'<b>Veuillez approvisionner <u>le produit &nbsp;'.$nom.' &nbsp;</u>qui a atteint le niveau du stock minimum.La quantite disponible est &nbsp;:'.$quantiteproduit.'</b><br>';
	echo'<br>';
	
	                          }
	     
									  }
									  
							}
						


?>

</div>
</center>