<?php

include('verification.php');

?>

<?
include('menu2.php');
?>
<br />
<center>
<div id="global">
<?php 
//R�cuperer les infos du formulaire
if (isset($_POST['ref']))
$ref=$_POST['ref'];

if (isset($_POST['nom']))
$nom=$_POST['nom'];

if (isset($_POST['quantitedispo']))
$quantitedispo=$_POST['quantitedispo'];

if (isset($_POST['prixachat']))
$prixachat=$_POST['prixachat'];

if (isset($_POST['prixvente']))
$prixvente=$_POST['prixvente'];





$dateappro=date("Y-m-d H:i");

$benefice=$prixvente - $prixachat;


//echo var_dump($benefice).'<br>';
 if($benefice < 0){
echo '<h2>ATTENTION ERREUR PRIX DE VENTE ET PRIX ACHAT</h2>';
}

else{

//je veux mettre javascript









        $result = mysql_query("INSERT INTO produit() VALUES ('$ref','$nom','$quantitedispo','$prixachat','$prixvente','$benefice','$dateappro') ");
              if (!$result) 
			  {
               die('Impossible d\'ex�cuter la requ�te :' . mysql_error());
              }
			  else {
			       echo 'Insertion reussie<br>';
				   $alban=mysql_query("INSERT INTO proceder_ventes() VALUES ('','$nom')");
				   @header('Location:ajout_produit.php');
			        }
}
?>			  




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>


</head>

<body>




</body>

</html></div></center>
<br />
<?php include('footer.php')  ; ?>