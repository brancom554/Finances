<?php
session_start();
include('verification.php');

?>
<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<?php include('menu2.php'); ?>
<br>
<center>
<div id="global">
<br><br>
<center><b>LISTE DES CLIENTS</b></center><br>
<table>
<tr>
<td>NOM CLIENT</td><td>CONTACT</td><td>CATEGORIE SOCIALE</td><td>Date ACHAT</td><td>SON VENDEUR</td><td>MONTANT ACHAT</td>
</tr>

<?php

$req=mysql_query("SELECT * FROM facture ") or die('Erreur sql'.mysql_error()) ;
$data=mysql_num_rows($req);
for($j=0;$j<$data;$j++)
     {
	 $nomproduit=mysql_result($req,$j,"nomclient");
	 $contact=mysql_result($req,$j,"telephone");
	 $quantitecommande=mysql_result($req,$j,"categorie_sociale");
	 $datecommande=mysql_result($req,$j,"datefacture");
	 $datelivraison=mysql_result($req,$j,"editeurfacture");
	 $fournisseur=mysql_result($req,$j,"total_achat");
	 echo'<tr>';
	 echo'<td>'.$nomproduit.'</td>';
	 echo'<td>'.$contact.'</td>';
	 echo'<td>'.$quantitecommande.'</td>';
	 echo'<td>'.$datecommande.'</td>';
	 echo'<td>'.$datelivraison.'</td>';
	 echo'<td>'.$fournisseur.'</td>';
	 echo'</tr>';
	 }
	 
	 
?>

</table>
<br><br>
</div>
</center>
<br>
<?php include('footer.php') ;?>
</body>
</html>