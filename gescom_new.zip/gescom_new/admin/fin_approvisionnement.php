
<?php
include('../config.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head>

<body>
<?php include('menu2.php'); ?>

<center>
<br />
<div id="global">

<br /><br /><br />
<center>
<?php
if(isset($_POST['Envoyer'])) {
$infos=$_POST['info'];
$date=date("Y-m-d");
//insertion dans la table journal_appro(id,dateap date,infos);
mysql_query("INSERT INTO journal_appro VALUES('','$date','$infos')")or die('Erreur sql:'.mysql_error());
mysql_query("UPDATE approvisionnement SET statut='1' WHERE statut='0' ") or die('Erreur sql:'.mysql_error());
?>
<br><b>APPROVISIONNEMENT TERMINE</b><br>
<?php
}
else {
?>
<br>
<b>VEUILLEZ AJOUTER DES DETAILS A  L'APPROVISIONNEMENT DE CE JOUR</b>
<form action="" method="post">
<table>
<tr>
<td><label id="info">AJOUTER INFOS</label></td><td><textarea name="info" ></textarea></td></tr>
<tr>
<td><input type="submit" name="Envoyer" value="Valider"></td></tr>
</table>
</form>
<?php
}
?>
</center>
<br />
	 	 

</div><br />
<?php include('footer.php'); ?>
</center>
</body>
</html>