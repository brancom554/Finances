<?php
session_start();
include('verification.php');


?>

<?php
$vente_total=0;
$benefice_total=0;
include('menu2.php');
echo'<br><br>';

?>
<center>
<div id="global">

<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<?php
if(isset($_POST['Envoyer'])) {
if (isset($_POST['date1']))
$date1=datefrenus($_POST['date1']);
if (isset($_POST['date2']))
$date2=datefrenus($_POST['date2']);


echo'<br><br>';
echo'<center>';
echo'RAPPORT DE VENTE POUR LA PERIODE DE &nbsp;'.$date1.'&nbsp;A&nbsp;'.$date2;
echo'</center>';
echo'<br><br>';
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					echo '<td>Prix Produit</td>';
					echo '<td>Vendeur</td>'; 
                   echo '<td>Quantite</td>';
				   echo '<td>Somme des ventes</td>';
				   echo '<td>DATE</td>';
				   echo'<td>CLIENT</td>';
				   echo'<td>Telephone</td>';
				   echo'<td>Heure de ventes</td>';
                    echo '</tr>';


				  
				  $query=mysql_query("SELECT * FROM calculer_ventes WHERE datevente BETWEEN '$date1' AND '$date2' ORDER BY nomproduit");
					
					if($query) {
					
                     $n = mysql_num_rows($query);
                    
					 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
 $heurevente=mysql_result($query,$i,"heurevente");
 
 //Selection du prix pour le calcul des ventes
 $req=mysql_query("SELECT prixvente,benefice FROM produit WHERE nom='$nomproduit' ");
 $req1=mysql_fetch_array($req);
 $prixvente=$req1['prixvente'];
 $benefice=$req1['benefice'];
 //calcul de la somme des ventes et des benefices
 $sommevente=$quantiteproduit * $prixvente;
 $vente_total=$sommevente + $vente_total;
 $benefice1=$quantiteproduit * $benefice;
 $benefice_total= $benefice_total + $benefice1 ;
 //Selection du client de la table facture
 $req=mysql_query("SELECT nomclient,telephone FROM facture WHERE datefacture='$date' AND heurevente='$heurevente' ");
 $req1=mysql_fetch_array($req);
 $client=$req1['nomclient'];
 $client2=$req1['telephone'];
 
 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					echo '<td>'.$prixvente.'</td>'; 
					echo '<td>'.$vendeur.'</td>'; 
                   echo '<td>'.$quantiteproduit.'</td>';
				   echo '<td>'.$sommevente.'</td>';
				   echo'<td>'.$date.'</td>';
				   echo'<td>'.$client.'</td>';
				   echo'<td>'.$client2.'</td>';
                   echo'<td>'.$heurevente.'</td>';
                    echo '</tr>';        
									  }
							}

echo'<tr>';
echo'<td></td><br>';
//echo'<td></td>';
echo'<td>VENTES TOTALES </td>';
echo '<td>'.$vente_total.'</td>';
echo'</tr>';
echo'<tr><td></td>';
echo'<td>BENEFICE TOTAL </td>';
echo '<td>'.$benefice_total.'</td>';
echo'</tr>';
echo '</table><br><br>';
								
		}else
		
		{
		echo'<br><br><br><b>Vous navez entre aucunes informations.Veuillez cliquez <a href="voir_vente.php">ici</a></b><br><br><br>';
		//header('Location:index.php');
		}							  
?>			


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>VOIR VENTES 2</title>
</head>

<body>

</body>
</html>
</div>
</center>
<br>

<br>
<?php include('footer.php'); ?>						  