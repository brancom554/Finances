&#65279;<?php

include('verification.php');


?>

<?php


$vente_total=0;


?>

<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<?php
if(isset($_POST['Envoyer'])) {
if (isset($_POST['date3']))
$date3=$_POST['date3'];
if (isset($_POST['date4']))
$date4=$_POST['date4'];

if (isset($_POST['vendeur']))
$vendeur=$_POST['vendeur'];


echo'<br><br>';
echo'<center>';
echo'RAPPORT DE VENTE POUR LA PERIODE DE &nbsp;'.$date3.'&nbsp;A&nbsp;'.$date4;
echo'</center>';
echo'<br><br>';
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					echo '<td>Prix Produit</td>';
					echo '<td>Vendeur</td>'; 
                   echo '<td>Quantite</td>';
				   echo '<td>Somme des ventes</td>';
				   //echo '<td>DATE</td>';
                    echo '</tr>';


				  
				  $query=mysql_query("SELECT * FROM calculer_ventes WHERE vendeur='$vendeur' AND datevente BETWEEN '$date3' AND '$date4' ");
					
					if($query) {
					
                     $n = mysql_num_rows($query);
                    
					 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
  $heurevente=mysql_result($query,$i,"heurevente");

 //Selection du prix pour le calcul des ventes
 $req=mysql_query("SELECT prixvente FROM produit WHERE nom='$nomproduit' ");
 $req1=mysql_fetch_array($req);
 $prixvente=$req1['prixvente'];
 //calcul de la somme des ventes
 $sommevente=$quantiteproduit * $prixvente;
 $vente_total=$sommevente + $vente_total;
 
  //Selection du client de la table facture
 $req=mysql_query("SELECT nomclient,telephone FROM facture WHERE datefacture='$date' AND heurevente='$heurevente' ");
 $req1=mysql_fetch_array($req);
 $client=$req1['nomclient'];
 $client2=$req1['telephone'];
 

 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					echo '<td>'.$prixvente.'</td>'; 
					echo '<td>'.$vendeur.'</td>'; 
                   echo '<td>'.$quantiteproduit.'</td>';
				   echo '<td>'.$sommevente.'</td>';
				   echo'<td>'.$date.'</td>';
				   echo'<td>'.$client.'</td>';
				   echo'<td>'.$client2.'</td>';
                   echo'<td>'.$heurevente.'</td>';
                    echo '</tr>';     
                            
									  }
							}

echo'<tr>';
echo'<td></td><br>';
//echo'<td></td>';
echo'<td>TOTAL </td>';
echo '<td>'.$vente_total.'</td>';
echo'</tr>';
echo '</table>';
								
		}else
		
		{
		echo'<br><br><br>';
echo'<center>';
echo'<legend>FAIRE DES RECHERCHES</legend>';
echo'<form action="" method="post">';
echo'<label>VEUILLEZ CHOISIR LE NOM DU VENDEUR</label> <select name="vendeur">';


$query=mysql_query("SELECT * FROM connexion");
$data=mysql_num_rows($query);

for($i=0;$i<$data;$i++)
  {
  $nom=mysql_result($query,$i,"pseudo");
  
 echo' <option>'.$nom.' </option>';
	
  }


echo'</select>
&nbsp;<br><br>';
echo'<label>PERIODE ALLANT DE</label>&nbsp;<div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" id="fro" name="date3"  />&nbsp;<label>A</label>&nbsp;<input type="text" id="t" name="date4"  /></div></div><br><br>';
echo'<input type="submit" name="Envoyer" value="Rechercher" />';

echo'</center>';
		}							  
?>			



						  