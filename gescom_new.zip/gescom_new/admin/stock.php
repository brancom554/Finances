﻿<?php
include('verification.php');
//include('stat.php');
?>

<?php

echo'<div class="bouton">
<ul>
<a href="inventaire.php">INVENTAIRE</a></li>
<a href="comptes/approv.php">Voir les approvisionnements</a></li>
<a href="voir_vente.php">RAPPORTS </a>
<a href="comptes/index.php">GERER USER</a>
<a href="../../jpowered/demo/examples/interface.htm">GERER LES STATS</a>

<a href="deconnexion.php">DECONNEXION</a>

</ul>
</div><br><br><br><br><br>';

?>

<?php
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> REF</td>';
                    echo '<td>Nom produit</td>'; 
                   echo '<td>Quantite</td>';
                    echo '</tr>';
					
					
				
				$query=mysql_query("SELECT * FROM produit ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	
					
              
					
					else {
  $n =mysql_num_rows($query);
 for($i=0;$i<$n;$i++) {
 
  $ref=mysql_result($query,$i,"ref"); 
   $nom=mysql_result($query,$i,"nom"); 
 $quantitedispo=mysql_result($query,$i,"quantitedispo"); 
 
 echo'<tr height="10">';
                   
                   echo'<td>'.$ref.'</td>';
                    echo '<td>'.$nom.'</td>'; 
                   echo '<td>'.$quantitedispo.'</td>';
                    echo '</tr>';        
									  }
									  
							}
									  
echo '</table>';


?>
<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>

</body>
</html>