<?php
session_start();
include('verification.php');
//$_GET['page']='';
?>

<?php
include('menu2.php');
echo'<br><br>';

?>
<center>
<div id="global">
<br><br>
<?php
echo'<legend>FAIRE DES RECHERCHES</legend>';
echo'<form action="inventaire1.php" method="post">';
echo'<label>PERIODE ALLANT DE</label>&nbsp;<div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" id="from" name="date1"  />&nbsp;<label>A</label>&nbsp;<input type="text" id="to" name="date2"  /></div></div><br><br>';
echo'<input type="submit" name="Envoyer" value="Rechercher" />';

echo'</center>';

echo'</form>';
//echo'<br /><br />';
/*
echo'
RAPPORTS INVENTAIRE<br>
<a href="inventaire.php?page=inventaire2.php" title="inventaire">Cliquez ici</a> <br>';*/
?>


<?php

/*
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   //echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					echo '<td>Prix de Vente</td>';
					echo '<td>Benefice</td>'; 
                   echo '<td>Quantite</td>';
				   echo '<td>Prix de Vente Total</td>';
				   echo '<td>Benefice attendu</td>';
				   echo '<td>Date de consultation</td>';
                    echo '</tr>';
					
					$link= mysql_connect('localhost', 'root', '');
               if (!$link) 
			   {
              die('Impossible de se connecter : ' . mysql_error());
               }
             if (!mysql_select_db('gestion')) 
			      {
                die('Impossible de slectionner la table : ' . mysql_error());
                  }
				
				$query=mysql_query("SELECT * FROM produit ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	
					
              
					
					else {
  $n =mysql_num_rows($query);
 for($i=0;$i<$n;$i++) {
 
  //$id=mysql_result($query,$i,"id"); 
   $nom=mysql_result($query,$i,"nom"); 
   $quantiteproduit=mysql_result($query,$i,"quantitedispo"); 
   $benefice=mysql_result($query,$i,"benefice"); 
 $prixvente=mysql_result($query,$i,"prixvente"); 
 //$date=mysql_result($query,$i,"datevente");
 $prixvente_total= $prixvente * $quantiteproduit;
 $benefice1_total= $benefice * $quantiteproduit;
 $date_de_consultation =date("Y-m-d");
 echo'<tr height="10">';
                   
                  // echo'<td>'.$id.'</td>';
                    echo '<td>'.$nom.'</td>'; 
					echo '<td>'.$prixvente.'</td>'; 
					echo '<td>'.$benefice.'</td>'; 
                   echo '<td>'.$quantiteproduit.'</td>';
				   echo'<td>'.$prixvente_total.'</td>';
				   echo'<td>'.$benefice1_total.'</td>';
				   echo'<td>'.$date_de_consultation.'</td>';
                    echo '</tr>';  
					
					if($quantiteproduit <= 5){
					//header('Location:alerte.php'); 
					echo 'ATTENTION A VOS STOCKS<br>'; }    
									  }
									  
							}
									  
echo '</table>';
*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>PAGE INVENTAIRE</title>

<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>

<body>

<center>


<?php
if(!empty($_GET['page']))
include($_GET['page']);
?>


</center>
</body>
</html>
</div></center>
<br />
<?php include('footer.php'); ?>