<?php
session_start();
include('verification.php');
?>
<?php
include('menu2.php');
?>
<br><center>
<div id="global">
<br /><br />
<?php
echo'<legend>FAIRE DES RECHERCHES</legend>';
echo'<form action="voir_vente1.php" method="post">';
echo'<label>PERIODE ALLANT DE</label><div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" name="date1" id="from" />&nbsp;<label>A</label>&nbsp;&nbsp;<input type="text" name="date2" id="to" /> </div></div>';
echo'<input type="submit" name="Envoyer" value="Rechercher" />';


echo'</form>';
?>

<?php

echo'<br><br><br>';
echo'<center>';
echo'CLIQUER ICI VOIR LES RAPPORTS VENTES EN FONCTION DU VENDEUR<br>';
echo'<a href="voir_vente.php?page=voir_vente2.php" title="Les Ventes">Cliquez ici</a> <br>';
echo'</center>';
/*
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					echo '<td>Prix Produit</td>';
					echo '<td>Vendeur</td>'; 
                   echo '<td>Quantite</td>';
				   echo '<td>DATE</td>';
                    echo '</tr>';
					
					$link= mysql_connect('localhost', 'root', '');
               if (!$link) 
			   {
              die('Impossible de se connecter : ' . mysql_error());
               }
             if (!mysql_select_db('gestion')) 
			      {
                die('Impossible de slectionner la table : ' . mysql_error());
                  }
				
				$query=mysql_query("SELECT * FROM calculer_ventes ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	
					
              
					
					else {
  $n =mysql_num_rows($query);
 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					echo '<td>'.$prixproduit.'</td>'; 
					echo '<td>'.$vendeur.'</td>'; 
                   echo '<td>'.$quantiteproduit.'</td>';
				   echo'<td>'.$date.'</td>';
                    echo '</tr>';        
									  }
									  
							}
									  
echo '</table>';

*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>VOIR VENTES</title>

<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>

<body>
<br /><br />
<center>


<?php
if(!empty($_GET['page']))
include($_GET['page']);
?>




</center>
		
</body>
</html>
</div>
</center>
<br />
<?php include('footer.php'); ?>						  
<br />