<?php

include('verification.php');
?>

<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<?php
include('menu2.php');
echo'<br>';
?>
<center>
<div id="global">
<br />
<?php
if(isset($_POST['Envoyer'])){
if(isset($_POST['produit']))
$nom=$_POST['produit'];

if(isset($_POST['date1']))
$date1=datefrenus($_POST['date1']);

if(isset($_POST['date2']))
$date2=datefrenus($_POST['date2']);


				  
					echo'<br><br><b>LISTE DES INVENTAIRES DE &nbsp;'.$date1.'&nbsp; A &nbsp;'.$date2.'</b><br><br>';

					 $quete = mysql_query("SELECT * FROM journal_inventaire WHERE dateap BETWEEN '$date1' AND '$date2 '")or die('erreur sql:'.mysql_error());
					$validation= mysql_num_rows($quete);
					if($validation==0) {
					echo'<b>Il n\'existe aucun inventaire pour cette periode</b><br><br><br>';}
					else {
					echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Dates Inventaires </td>';
					//echo '<td>Infos</td>';
					
	echo '</tr>';

					
for($a=0;$a<$validation;$a++ )
{
$id=mysql_result($quete,$a,"id");
$date=mysql_result($quete,$a,"dateap");
//$infos=mysql_result($quete,$a,"infos");
   echo'<tr height="10">';
   echo'<td>'.$id.'</td>';
   echo '<td><a href="archive_inventaire.php?action='.$date.'">'.$date.'</a></td>';
   //echo '<td>'.$infos.'</td>'; 
   echo '</tr>';        
									  }
							//}
echo '</table><br><br>';

//envoi des d�tails en fonction des dates
/*if(isset($_GET['action']) )
{
$action = $_GET['action'];
$demande=mysql_query("select * from approvisionnement where dateap='$action' ")or die('Erreur sql:'.mysql_error());
$nombre=mysql_num_rows($demande);
echo'<b>LISTE DES APPROVISIONNEMENTS CONCERNES</b><br>';
echo'
<table>
<tr>
<td>ID</td><td>NOM ARTICLE</td><td>QUANTITE APPORTEE</td>
</tr>
';
for($l=0;$l<$nombre;$l++) {
      $id=mysql_result($demande,$l,"id");
	  $nomproduit=mysql_result($demande,$l,"nom");
	  $quantite=mysql_result($demande,$l,"quantite");
	  echo'<tr>';
	  echo'<td>'.$id.'</td>';
	  echo'<td>'.$nomproduit.'</td>';
	  echo'<td>'.$quantite.'</td>';
	  echo'</tr>';
       }
echo'</table>';
}*/
//fin envoi des d�tails 
//envoi des d�tails en fonction des dates
            }

  }
  else{
?>

<?php
echo'<br><br><br>';
echo '&nbsp;&nbsp;';
echo'<marquee><h3>PAGE DES INVENTAIRES ARCHIVES</h3> </marquee>';
echo'<br><br>';
echo'<center>';
echo'<legend>PAGE DES INVENTAIRES ARCHIVES </legend>';
echo'<form action="" method="post">';
//echo'<label>VEUILLEZ METTRE LE NOM DU PRODUIT</label> <input type="text" name="produit"  />&nbsp;<br><br>';
echo'<label>PERIODE ALLANT DE</label>&nbsp;<div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" id="from" name="date1"  />&nbsp;<label>A</label>&nbsp;<input type="text" id="to" name="date2"  /></div></div><br><br>';
echo'<input type="submit" name="Envoyer" value="Rechercher" />';

echo'</center>';
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>
<body>

</body>
</html></div></center>
<br />
<?php include('footer.php')  ; ?>