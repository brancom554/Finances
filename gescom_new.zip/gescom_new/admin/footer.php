	
	<style type="text/css">
	/*Message du coptright */
 .generatecssdotcom_neon_53d8d0cb5bb55 {position:absolute;top:0;right:0;font-size:8px;color:#cccccc;} .generatecssdotcom_neon_53d8d0cb5bb55 a {color:#cccccc;text-decoration:none;font-weight:normal;} .generatecssdotcom_neon_53d8d0cb5bb55 a:hover {color:#cccccc;text-decoration:none;font-weight:normal;} .generatecssdotcom_text_53d8d0cb5bb55 {font-size: 30px;font-family: Georgia;color: #006666;font-weight: bold;font-style: italic;text-shadow:0 0 10px #ffffff,0 0 20px #ffffff,0 0 30px #ffffff,0 0 40px #006666,0 0 70px #006666,0 0 80px #006666,0 0 100px #006666,0 0 170px #006666;} 
#bas{
background-color:#CDA633;
-webkit-border-radius: 4px 4px 6px 6px;
width:1100px;
height:auto;
 border-radius: 4px 4px 6px 6px;
   -webkit-box-shadow: inset 15px 2px 3px 3px #2020a6; box-shadow: inset 3px 2px 3px 3px #2020a6;

}
	</style>
	<center>
	<?php include('alerte1.php'); ?>	
	

	</center> 

<br />
      <br />
      <br />
    
    &nbsp;
    <div style="background-position:bottom; font-size:8px;">
	<center><b>COPYRIGHT Marius A.GANHOUEGNON,JAMES ENTERPRISE 2014 (C)  </b></center></div>
