﻿<?php
session_start();
include('verification.php');

?>
<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<?php include('menu2.php'); ?>
<br>
<center>
<div id="global">
<br><br>

<center><b>Cher utilisateur</b></center>
<br>
Suivez l’évolution des ventes et des achats de votre entreprise.<br>
Votre tableau de bord synthétise :<br>
Votre chiffre d’affaires mensuel.<br>
Un palmarès de vos meilleurs clients.<br>

Vos statistiques détaillées des ventes par clients, articles et commerciaux.<br>

<br>

</div>
</center>
<br>
<?php include('footer.php') ;?>
</body>
</html>