<?php

include('verification.php');

?>
<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>PAGE INVENTAIRE 2</title>
</head>

<body>

<?php
include('menu2.php');
echo'<br><br>';

?>
<center>
<div id="global">
<?

//include('verification.php');


?>

<?php
$vente_total=0;
if(isset($_POST['Envoyer'])) {
if (isset($_POST['produit']))
$produit=$_POST['produit'];
if(isset($_POST['date1']))
$date1=datefrenus($_POST['date1']);

if(isset($_POST['date2']))
$date2=datefrenus($_POST['date2']);
//if (isset($_POST['date2']))
//$date2=$_POST['date2'];
echo'<br><br><br>';
echo'<center>';
echo'PERIODE ALLANT DE &nbsp;'.$date1.'A&nbsp;'.$date2;
echo'</center>';
echo'<br><br>';
/*
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					 echo '<td>Quantites Vendues</td>';
					echo '<td>Prix Unitaire</td>';
					echo '<td>Montant total des Ventes</td>';

					echo'<td>Quantites Disponibles</td>';

					echo '<td>Vendeur</td>'; 
                  
				   echo '<td>DATE</td>';
                    echo '</tr>';
*/


				  
				  $query=mysql_query("SELECT * FROM calculer_ventes WHERE datevente BETWEEN '$date1' AND '$date2' AND statut='1' group by nomproduit");
					
					if($query) {
                     $n = mysql_num_rows($query);
                    if($n==0) {
					echo'<b>L\'INVENTAIRE SUR CETTE PERIODE A ETE DEJA FAIT!MERCI DE NE PAS INSISTER</b><br><br>';exit();}
					else
					{
					
					echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					 echo '<td>Quantites Vendues</td>';
					echo '<td>Prix Unitaire</td>';
					echo '<td>Montant total des Ventes</td>';

					echo'<td>Quantites Disponibles</td>';

					echo '<td>Vendeur</td>'; 
                  
				   echo '<td>DATE</td>';
                    echo '</tr>';

					
					
					 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
 
 //sommation des quantites vendues par produit
  $requete=mysql_query("SELECT sum(quantiteproduit) AS qq FROM calculer_ventes WHERE datevente BETWEEN '$date1' AND '$date2' AND nomproduit='$nomproduit' AND statut='1' ");
  $requete1=mysql_fetch_array($requete);
$quantiteproduit1=$requete1["qq"];
 //Selection du prix pour le calcul des ventes
 $req=mysql_query("SELECT prixvente,quantitedispo FROM produit WHERE nom='$nomproduit' ");
 $req1=mysql_fetch_array($req);
 $prixvente=$req1['prixvente'];
 $quantitedispo=$req1['quantitedispo'];
 $sommevente=$quantiteproduit1 * $prixvente;
 $vente_total=$sommevente + $vente_total;
 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					 echo '<td>'.$quantiteproduit1.'</td>';

					echo '<td>'.$prixvente.'</td>';
					echo '<td>'.$sommevente.'</td>'; 
 
		            echo '<td>'.$quantitedispo.'</td>';

					echo '<td>'.$vendeur.'</td>'; 

				   echo'<td>'.$date.'</td>';
                    echo '</tr>';        
									  }
							}

echo'<tr>';
echo'<td></td><br>';
//echo'<td></td>';
echo'<td>TOTAL </td>';
echo '<td>'.$vente_total.'</td>';
echo'</tr>';
echo '</table>';
echo'<br><br>';
echo'<center><a href="inventaire3.php"><b>CLOTURER INVENTAIRE</b></a><br><br><br>';}
		//mysql_query("UPDATE calculer_ventes SET statut='0' WHERE datevente BETWEEN '$date1' AND '$date2' ") or die('Erreur sql:'.mysql_error());
		}
		else
		{
		header('inventaire.php');
		}							  
?>			


<br />
				  
</div></center>
<br />
<?php include('footer.php'); ?>
</body>
</html>
