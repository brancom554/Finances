<?php


?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-2">
<title></title>
</head>
<body>
<?php
if(isset($_POST["choix"]))
{
echo "Vous avez choisi ".$_POST["choix"].".";
}
else
{
?>
<form method="post" action="">
<input name="choix" id="choix1" type="radio" value="1" />
<label for="choix1">ADMINISTRATEUR</label>
<input name="choix" id="choix2" type="radio" value="2" />
<label for="choix2">UTILISATEUR</label>

<input type="submit" value="Valider" />
</form>
<?php
}
?>



<?php

if (isset($_POST['choix'])){
$choix=$_POST['choix'];
//On met une verification de condition avec switch
switch($choix)
      {
	  case 1: header('Location:index1.php');
	  break;
	  case 2: header('Location:index2.php');
	  break;
	  default: echo 'Veuillez choisir une categorie<br>';
	            header('Location:');
				break;
	  
	  }

}

?>
</body>
</html> 