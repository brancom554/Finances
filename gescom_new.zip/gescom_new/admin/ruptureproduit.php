
<br><br>
<center>
<b><u>LISTE DES PRODUTS EN RUPTURE DE STOCK OU EN STOCK CRITIQUE</u></b>
<br><br>
<?php


$sql=mysql_query("SELECT * FROM produit WHERE quantitedispo BETWEEN 0 AND 10");
$data=mysql_num_rows($sql);
for($j=0;$j<$data;$j++)
     {
	 $nom=mysql_result($sql,$j,"nom");
	 $quantite=mysql_result($sql,$j,"quantitedispo");
	 echo $j.'-)'.$nom.'&nbsp;Quantite Restant&nbsp;:'.$quantite;
	 echo'<br>';
	 }
?>

</center>