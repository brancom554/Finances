<?php
session_start();
include('verification.php');
//$_GET['page']='';
?>

<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>PAGE CLOTURE INVENTAIRE 2</title>
</head>

<body>

<?php
include('menu2.php');
echo'<br><br>';

?>
<center>
<div id="global">
<?

//include('verification.php');


?>

<?php
$vente_total=0;
if(isset($_POST['Envoyer'])) {
if (isset($_POST['produit']))
$produit=$_POST['produit'];
if(isset($_POST['date1']))
$date1=datefrenus($_POST['date1']);

if(isset($_POST['date2']))
$date2=datefrenus($_POST['date2']);
?>

<center>
<div id="global">
<br><br>

<br /><br />





<center>
<?php
$date_inventaire=date("Y-m-d");

 @$quantitedispo=$req1['quantitedispo'];
mysql_query("UPDATE calculer_ventes SET statut='0' WHERE datevente BETWEEN '$date1' AND '$date2' ") or die('Erreur sql:'.mysql_error());
 mysql_query("INSERT INTO journal_inventaire VALUES('','$date_inventaire','$date1','$date2') ")or die('Erreur sql:'.mysql_error());
 
 //on prend en compte le stock restant
 
 $req=mysql_query("SELECT nom FROM produit ");
 $nb=mysql_num_rows($req);
 for($t=0;$t<$nb;$t++) {
 $nom=mysql_result($req,$t,"nom");
 $demande=mysql_query("select quantitedispo from produit where nom='$nom' ") or die('Erreur sql:'.mysql_error());
 $demande1=mysql_fetch_array($demande);
 $quantitedispo=$demande1["quantitedispo"];
 mysql_query("INSERT INTO journal_inventaire2 VALUES('','$date_inventaire','$nom','$quantitedispo') ") or die('Erreur sql:'.mysql_error());
 
                     }
 //$prixvente=$req1['prixvente'];                            
?>
<center><b>VOUS VENEZ DE CLOTURER L\'INVENTAIRE DE LA PERIODE SELECTIONNEE</b></center><br><br>			
<a href="index.php">CLIQUEZ ICI POUR CONTINUER</a>
<?php		
  }					 
if(isset($_POST['Annuler']))  {


?>                              

<b><br /><br /><br />VOTRE ACTION DE FERMER L\'INVENTAIRE A ETE ANNULEE</b><br /><br /><br />
<?php

}
//if(!empty($_GET['page']))
//include($_GET['page']);
?>

</center>
</center>
</div>

</center>
<br />
<?php include('footer.php'); ?>

