<?php

include('verification.php');

				  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>
<body>
<?php
include('menu2.php');
echo'<br>';
?>
<center>
<div id="global">
<br />
<?php
if(isset($_GET['action']) )
{
$action = $_GET['action'];
$vente_total=0;
//selection des periodes depuis la table journal_inventaire
$alpha=mysql_query("select * from journal_inventaire where dateap='$action' ")or die('Erreur sql:'.mysql_error());
$alpha1=mysql_fetch_array($alpha);
$periode1=$alpha1["periode1"];
$periode2=$alpha1["periode2"];

$query=mysql_query("select * from calculer_ventes where datevente between '$periode1' and '$periode2' and statut='0' group by nomproduit")or die('Erreur sql:'.mysql_error());
$nombre=mysql_num_rows($query);
echo'<br><b>LISTE DES ARTICLES  CONCERNANT L\'INVENTAIRE DE LA DATE DU '.$action.'</b><br>';
echo'';
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					 echo '<td>Quantites Vendues</td>';
					echo '<td>Prix Unitaire</td>';
					echo '<td>Montant total des Ventes</td>';

					echo'<td>Quantites Disponibles</td>';

					echo '<td>Vendeur</td>'; 
                  
				   echo '<td>DATE</td>';
                    echo '</tr>';

					
					
					 for($i=0;$i<$nombre;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
 
 //sommation des quantites vendues par produit
  $requete=mysql_query("SELECT sum(quantiteproduit) AS qq FROM calculer_ventes WHERE datevente BETWEEN '$periode1' AND '$periode2' AND nomproduit='$nomproduit' AND statut='0' ");
  $requete1=mysql_fetch_array($requete);
$quantiteproduit1=$requete1["qq"];
 //Selection du prix pour le calcul des ventes
 $req=mysql_query("SELECT prixvente FROM produit WHERE nom='$nomproduit' ");
 $req1=mysql_fetch_array($req);
 $prixvente=$req1['prixvente'];
 
 $req2=mysql_query("SELECT quantitedispo FROM journal_inventaire2 WHERE dateap='$action' AND nomproduit='$nomproduit' ");
 $req3=mysql_fetch_array($req2);
 $quantitedispo=$req3['quantitedispo'];
 
 $sommevente=$quantiteproduit1 * $prixvente;
 $vente_total=$sommevente + $vente_total;
 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					 echo '<td>'.$quantiteproduit1.'</td>';

					echo '<td>'.$prixvente.'</td>';
					echo '<td>'.$sommevente.'</td>'; 
 
		            echo '<td>'.$quantitedispo.'</td>';

					echo '<td>'.$vendeur.'</td>'; 

				   echo'<td>'.$date.'</td>';
                    echo '</tr>';        
									  }
							//}

echo'<tr>';
echo'<td></td><br>';
//echo'<td></td>';
echo'<td>TOTAL </td>';
echo '<td>'.$vente_total.'</td>';
echo'</tr>';
echo '</table><br><br>';

}

?>
</div></center>
</body>
</html>
<br />
<?php include('footer.php')  ; ?>