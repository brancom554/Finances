
<table>
<tr>
<td>PRODUIT</td><td>Quantite command&eacute;e</td><td>Date commande</td><td>Date livraison</td><td>Fournisseur</td>
</tr>

<?php


$req=mysql_query("SELECT * FROM commande ") or die('Erreur sql'.mysql_error()) ;
$data=mysql_num_rows($req);
for($j=0;$j<$data;$j++)
     {
	 $nomproduit=mysql_result($req,$j,"nomproduit");
	 $quantitecommande=mysql_result($req,$j,"quantitecommande");
	 $datecommande=mysql_result($req,$j,"datecommande");
	 $datelivraison=mysql_result($req,$j,"datelivraison");
	 $fournisseur=mysql_result($req,$j,"fournisseur");
	 echo'<tr>';
	 echo'<td>'.$nomproduit.'</td>';
	 echo'<td>'.$quantitecommande.'</td>';
	 echo'<td>'.$datecommande.'</td>';
	 echo'<td>'.$datelivraison.'</td>';
	 echo'<td>'.$fournisseur.'</td>';
	 echo'</tr>';
	 }
	 
	 
?>

</table>