<?php

include('verification.php');

?>

<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<?php
if(isset($_POST['Envoyer'])){

if(isset($_POST['produit']))
$nom=$_POST['produit'];

if(isset($_POST['date3']))
$date3=$_POST['date3'];

if(isset($_POST['date4']))
$date4=$_POST['date4'];


				//on selectionne les quantites des produits vendus et on les additionne en fonction d'une date donn�e 
				//Ou carrement autoriser le script a le faire chaque semaine
				
				/*$query=mysql_query("SELECT * FROM calculer_ventes WHERE nomproduit=  AND datevente BETWEEN $date1 AND $date2 ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	*/
			 $query=mysql_query("SELECT sum(quantiteproduit) AS quantite_total FROM calculer_ventes WHERE nomproduit='$nom' AND datevente BETWEEN '$date3' AND '$date4' ");
			  if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }
			  else
			  {
			  $data = mysql_fetch_assoc($query);
               $total = $data['quantite_total'];
			   //echo 'Nous avons vendu' .$total;
			   
			   //Selection du prix du produit
					$req=mysql_query("SELECT prixvente,prixachat FROM produit WHERE nom='$nom' ");
					$req1=mysql_fetch_assoc($req);
					$prix=$req1['prixvente'];
					$prix1=$req1['prixachat'];
					$prixtotal=$prix * $total;
					$prixtotal1=$prix1 * $total;
					$benefice=$prixtotal - $prixtotal1; 
			   echo'<table cellpadding="" cellspacing="" border="" >';
			   echo'<tr>';
			   echo'<td>Produits</td>';
			   echo'<td>Quantites vendues</td>';
			   echo'<td>Somme des ventes</td>';
			   echo'<td>Benefice effectue</td>';
			   echo'<td>Periode de </td>';
			   echo'<td>A </td>';
			   echo'</tr>';
			   
			   echo'<tr>';
			   echo'<td>'.$nom.'</td>';
			   echo'<td>'.$total.'</td>';
			   echo'<td>'.$prixtotal.'</td>';
			   echo'<td>'.$benefice.'</td>';
			   echo'<td>'.$date3.' </td>';
			   echo'<td>'.$date4.'</td>';
			   echo'</tr>';
			   
			   echo'</table>';
			   echo'<br><br>';
			   echo'<a href="stock.php">Cliquez ici pour voir le stock restant</a>';
			  }
			  
			  
			  /*SELECT facture_id, SUM(prix) AS prix_total
FROM facture
GROUP BY facture_id
c'est pour grouper les lignes en se basant sur la colonne � facture_id �.*/





//$total = mysql_result($req, 0, 'total_operations');
    }
	else {
?>


<?php
echo'<br><br><br>';
echo'<center>';
echo'<legend>FAIRE DES RECHERCHES</legend>';
echo'<form action="" method="post">';
echo'<label>VEUILLEZ METTRE LE NOM DU PRODUIT</label> <input type="text" name="produit"  />&nbsp;<br><br>';
echo'<label>PERIODE ALLANT DE</label>&nbsp;<div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" id="fro" name="date3"  />&nbsp;<label>A</label>&nbsp;<input type="text" id="t" name="date4"  /></div></div><br><br>';
echo'<input type="submit" name="Envoyer" value="Rechercher" />';

echo'</center>';
}
?>

			  