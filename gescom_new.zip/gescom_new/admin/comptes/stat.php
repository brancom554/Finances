<?php﻿

mysql_connect("localhost","root","");
mysql_select_db("gestion");
// cf cours sur mysql à droite

// on ouvre la session
session_start();

if(!isset($_SESSION['parcours']))
{
// il s'agit d'un nouveau visiteur, on crée $_SESSION['parcours'] et $_SESSION['time']
$_SESSION['time'] = time();
$_SESSION['parcours']= $_SERVER['REQUEST_URI'];

$parcours=$_SESSION['parcours'];
$time=$_SESSION['time'];
// on crée un enregistrement dans la table
$sql = "INSERT INTO statistique (referer,time,parcours,sessid)";
$sql .= "VALUES ('".$_SERVER['HTTP_REFERER']."','$time','$parcours','".session_id()."')";
}
else
{
//Sinon c'est un visiteur déjà présent, on ajoute la nouvelle page vue, séparée par un point virgule, à la variable de session
$_SESSION['parcours'].= ';'.$_SERVER['REQUEST_URI'];

// on ajoute à la variable de session l'heure à laquelle la page a été vue
$_SESSION['time'].= ';'.time();

// on met la table à jour
$parcours=$_SESSION['parcours'];
$time=$_SESSION['time'];
$sql = "UPDATE statistique SET parcours='$parcours',time='$time'";
$sql .= "WHERE sessid='".session_id()."'";
}

//Enfin on exécute la requête dans tous les cas
mysql_query($sql) or die('Erreur SQL !
'.$sql.'
'.mysql_error());


?>