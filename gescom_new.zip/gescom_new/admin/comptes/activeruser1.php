<?php

include('verification.php');
?>
<?php

include('menu2.php');
?>

<?php 
//R�cuperer les infos du formulaire

if(isset($_POST['Envoyer'])) {
if (isset($_POST['nom']))
$nom=$_POST['nom'];


$date=date("Y-m-d");



			$req= mysql_query("SELECT pseudo FROM log WHERE dateap='$date'");
			if($req) {
			
			$dat=mysql_fetch_array($req,MYSQL_ASSOC);
                            $vendeur=$dat["pseudo"];
			         }
              

$query=mysql_query("UPDATE connexion SET statut='1' WHERE pseudo='$nom' ");
					
					if($query) {
                     //$n = mysql_num_rows($query);
                       
					echo 'OPERATION REUSSIE<br>';
					//header('Location:approvisionner.php');
					//$req= mysql_query("INSERT INTO journaldesprix() VALUES('','$nom','$quantitedispo','$vendeur','$date')");
					//if($req) echo'REUSSITE<br>';
                      
			        }
					
			}else
			header('Location:activeruser.php');		
?>
</center>			

<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<br />
<center>
<div id="global">
<br>
<center>

&nbsp;&nbsp;&nbsp;&nbsp;<b>OPERATION EFFECTUEE AVEC SUCCES</b>

</center>
<script type="text/javascript">
<!--
var obj = 'window.location.replace("activeruser.php");';
setTimeout(obj,1000);
// -->
</script>
<br />
</div>
<br />
<?php include('footer.php'); ?>
</body>
</html>		