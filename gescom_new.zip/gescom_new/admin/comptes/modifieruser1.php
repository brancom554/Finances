<?php

include('verification.php');
if(isset($_POST['Envoyer'])) {
$nom=$_POST['nom'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<script type="text/javascript">

function verifForm(f)
{
   var ageOk = verifAge(f.quantitedispo);
   
   
   if(ageOk)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}

function verifAge(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 15000000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}

function verifAge2(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}


function verifAge3(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}
</script>

</head>

<body>
<?php include('menu2.php'); ?>

<center>
<br />
<div id="global">

<br /><br /><br />
<b>ATTRIBUTS DES UTILISATEURS</b><br />
<form action="modifieruser2.php" method="post" onsubmit="return verifForm(this)">
	<table cellpadding="1" cellspacing="1" border="1">
	<tr><td>DESIGNATION</td><td>VALEUR ASSOCIEE</td>
	</tr><br>


<?php

$query=mysql_query("SELECT * FROM connexion WHERE id='$nom' ");
$data=mysql_num_rows($query);

for($i=0;$i<$data;$i++)
  {
  $pseudo=mysql_result($query,$i,"pseudo");
  $passe=mysql_result($query,$i,"passe");
  $email=mysql_result($query,$i,"email");
 $nom_user=mysql_result($query,$i,"nom_user");
  $prenom_user=mysql_result($query,$i,"prenom_user");
  $telephone=mysql_result($query,$i,"telephone");
	
  }
?>
<tr>
	<td><label id="">PSEUDO </label></td>
	<td><input type="text" name="pseudo" value="<?php echo $pseudo;?>"></td>
	</tr>
<tr>
	<td><label id="">PASSE </label></td>
	<td><input type="text" name="passe" value="<?php echo $passe;?>"></td>
	</tr>
	
<tr>
	<td><label id="">EMAIL </label></td>
	<td><input type="text" name="email" value="<?php echo $email;?>"></td>
	</tr>	
	<tr>
	<td><label id="">NOM </label></td>
	<td><input type="text" name="nom_user" value="<?php echo $nom_user;?>"></td>
	</tr>
	<td><label id="">PRENOM </label></td>
	<td><input type="text" name="prenom_user" value="<?php echo $prenom_user;?>"></td>
	</tr>
	<td><label id="">TELEPHONE</label></td>
	<td><input type="text" name="telephone" value="<?php echo $telephone;?>"></td>
	</tr>
	<tr>
   <td> </td> <td><input type="submit" name="Envoyer" value="Actualiser"></td>
   </tr>
   </table>
     </form>
	 <br /><br />
	 </center>
	 <br />
	 	 <?php 
		 }
		 include('footer.php'); ?>

	 </div>
	 </body>
	 </html>