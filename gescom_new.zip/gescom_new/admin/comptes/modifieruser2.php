<?php

include('verification.php');
?>
<?php

include('menu2.php');
?>

<?php 
//R�cuperer les infos du formulaire

if(isset($_POST['Envoyer'])) {
if (isset($_POST['pseudo']))
$nom=$_POST['pseudo'];
$passe=$_POST['passe'];
$email=$_POST['email'];
$nom_user=$_POST['nom_user'];
$prenom_user=$_POST['prenom_user'];
$telephone=$_POST['telephone'];
$date=date("Y-m-d");




			$req= mysql_query("SELECT * FROM connexion WHERE pseudo='$nom' ");
			$req1=mysql_num_rows($req);
			if($req1 == 0) 
	$query=mysql_query("INSERT INTO  connexion VALUES('','$nom','$passe' ,'$email','1','1','$nom_user','$prenom_user','$telephone','0') ");
	else		
$query=mysql_query("UPDATE connexion SET passe='$passe' ,email='$email',nom_user='$nom_user',prenom_user='$prenom_user',telephone='$telephone' WHERE pseudo='$nom' ");
					
					if($query) {
                     //$n = mysql_num_rows($query);
                       
					echo 'OPERATION REUSSIE<br>';
					//header('Location:approvisionner.php');
					//$req= mysql_query("INSERT INTO journaldesprix() VALUES('','$nom','$quantitedispo','$vendeur','$date')");
					//if($req) echo'REUSSITE<br>';
                      
			        }
					
			}else
			header('Location:modifieruser.php');		
?>
</center>			

<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<br />
<center>
<div id="global">
<br>
<center>

&nbsp;&nbsp;&nbsp;&nbsp;<b>MODIFICATION EFFECTUEE AVEC SUCCES</b>

</center>
<script type="text/javascript">
<!--
var obj = 'window.location.replace("modifieruser.php");';
setTimeout(obj,1000);
// -->
</script>
<br />
</div>
<br />
<?php include('footer.php'); ?>
</body>
</html>		