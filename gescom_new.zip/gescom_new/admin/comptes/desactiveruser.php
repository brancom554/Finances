<?php

include('verification.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<script type="text/javascript">

function verifForm(f)
{
   var ageOk = verifAge(f.quantitedispo);
   
   
   if(ageOk)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}

function verifAge(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 15000000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}

function verifAge2(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}


function verifAge3(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 100000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}
</script>

</head>

<body>
<?php include('menu2.php'); ?>

<center>
<br />
<div id="global">

<br /><br /><br />

<form action="desactiveruser1.php" method="post" onsubmit="return verifForm(this)">
	<table cellpadding="1" cellspacing="1" border="1">
	<tr><td>DESIGNATION</td><td>VALEUR ASSOCIEE</td>
	</tr><br>
<tr>
	<td><label id="">NOM </label></td>
	<td><select name="nom">

<?php

$query=mysql_query("SELECT * FROM connexion WHERE acces='1' ");
$data=mysql_num_rows($query);

for($i=0;$i<$data;$i++)
  {
  $nom=mysql_result($query,$i,"pseudo");
  
 echo' <option>'.$nom.' </option>';
	
  }
?>

	
	</select></td>
	</tr>
	
	<tr>
   <td> </td> <td><input type="submit" name="Envoyer" value="Desactiver"></td>
   </tr>
   </table>
     </form>
	 <br /><br />
	 </center>
	 <br />
	 	 <?php include('footer.php'); ?>

	 </div>
	 </body>
	 </html>