﻿<?php
session_start();
include('../../config.php');
$pseudo=$_SESSION['pseudo'];

mysql_query("UPDATE connexion SET connecte='0' WHERE pseudo='$pseudo' ") or die('Erreur sql:'.mysql_error());

//$req=mysql_query("delete from log2 where pseudo='$pseudo' ");
session_unset();
session_destroy();
 header('location:../../index.php');

?>