<?php

$date=date("Y-m-d");
//$req=mysql_query("select * from log2 where dateap='$date' ") or die('Erreur sql:'.mysql_error());
//$req1=mysql_fetch_array($req);
//$pseudo=$req1["pseudo"];
$pseudo=$_SESSION['pseudo'];

?>
<style type="text/css">
#generatecssdotcome_nav{height:35px;font:normal .8em/1.5em Arial, Helvetica, sans-serif;margin:0;padding:7px 6px 0;line-height:100%;border-radius:2em;width:1100px;-webkit-border-radius:2em;-moz-border-radius:2em;-webkit-box-shadow:0 1px 3px rgba(0, 0, 0, .4);-moz-box-shadow:0 1px 3px rgba(0, 0, 0, .4);background:#8b8b8b;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#CC9900', endColorstr='#bfbf60');background:-webkit-gradient(linear, left top, left bottom, from(#CC9900), to(#bfbf60));background:-moz-linear-gradient(top, #CC9900, #bfbf60);border:solid 1px #794d20; }
 
#generatecssdotcome_nav li{margin:0 5px;padding:0 0 8px;float:left;position:relative;list-style:none;color:#CC9900}
 
#generatecssdotcome_nav a{font-weight:bold;color:#000000;text-decoration:none;display:block;padding:8px 20px;margin:0;-webkit-border-radius:1.6em; -moz-border-radius:1.6em;text-shadow:0 1px 1px rgba(0, 0, 0, .3);} 

#generatecssdotcome_nav .current a, #generatecssdotcome_nav li:hover > a{background:#3399FF;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#EBEBEB', endColorstr=' #A1A1A1');background:-webkit-gradient(linear, left top, left bottom, from(#EBEBEB), to( #A1A1A1));background:-moz-linear-gradient(top, #EBEBEB, #A1A1A1);color:#eb9040;border-top:solid 1px #f8f8f8;-webkit-box-shadow:0 1px 1px rgba(0, 0, 0, .3);-moz-box-shadow:0 1px 1px rgba(0, 0, 0, .2);box-shadow:0 1px 1px rgba(0, 0, 0, .2);text-shadow:0 1px 0 rgba(255, 255, 255, .8);} 

#generatecssdotcome_nav ul li:hover a, #generatecssdotcome_nav li:hover li a{background:none;border:none;color:#eb9040;-webkit-box-shadow:none;-moz-box-shadow:none;} 

#generatecssdotcome_nav ul a:hover{font-weight:bold;-webkit-border-radius:0;-moz-border-radius:0;text-shadow:0 1px 1px rgba(0, 0, 0, .1);}

 #generatecssdotcome_nav ul{filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#EBEBEB', endColorstr=' #A1A1A1');background:-webkit-gradient(linear, left top, left bottom, from(#EBEBEB), to( #A1A1A1));background:-moz-linear-gradient(top, #EBEBEB, #A1A1A1);display:none;margin:0;padding:0;width:185px;position:absolute;top:35px;left:0;border:solid 1px #794d20;-webkit-border-radius:10px;-moz-border-radius:10px;border-radius:10px;-webkit-box-shadow:0 1px 3px rgba(0, 0, 0, .3);-moz-box-shadow:0 1px 3px rgba(0, 0, 0, .3);box-shadow:0 1px 3px rgba(0, 0, 0, .3);} 
 
 #generatecssdotcome_nav li:hover > ul{display:block;} 
 
 #generatecssdotcome_nav ul li{float:none;margin:0;padding:0;} 
 
 #generatecssdotcome_nav ul a{font-weight:normal;text-shadow:0 1px 1px rgba(255, 255, 255, .9);} 
 
 #generatecssdotcome_nav:after{content:".";display:block;clear:both;visibility:hidden;line-height:0;height:0;} 
 
 #generatecssdotcome_nav{display:inline-block;} 
 
 html[xmlns] #generatecssdotcome_nav{display:block;} 
 
 .menu-background {position:absolute;top:0;right:0;font-size:8px;color:#006633} 
 
 .menu-background a {color:#cccccc;text-decoration:none;font-weight:normal;} 
 
 .menu-background a:hover {color:#cccccc;text-decoration:none;font-weight:normal;} 
 
 
 /* message d'accueil*/
  .generatecssdotcom_3d_53d8cdbf4ee0e {position:absolute;top:0;right:0;font-size:8px;color:#cccccc;} .generatecssdotcom_3d_53d8cdbf4ee0e a {color:#cccccc;text-decoration:none;font-weight:normal;} .generatecssdotcom_3d_53d8cdbf4ee0e a:hover {color:#cccccc;text-decoration:none;font-weight:normal;} .generatecssdotcom_text_53d8cdbf4ee0e {font-size: 80px;font-family: Georgia;color: #609f9f;font-weight: bold;font-style: italic;text-shadow:0 1px 0 #ccc, 0 2px 0 #c9c9c9,0 3px 0 #bbb, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15);} 
  
</style>

</head>
<body>
<div style="float:right ; margin:auto">
<?php echo '<b>'.$pseudo.'(Administrateur)</b>&nbsp;';?>&nbsp;<a href="deconnexion.php"><img src="gnome_shutdown.png" width="26" height="30"  title="Se deconnecter"></a>&nbsp;&nbsp;</div>
<center>
<br><br>

	<span class="generatecssdotcom_text_53d8cdbf4ee0e"> &nbsp;&nbsp;GESCOM  Version 1.1.2</span>
<br>
</center>
<br>
<center>
<ul id="generatecssdotcome_nav">

<li><a href="index1.php">ACCUEIL</a></li>
<li><a href="inscrire_membre.php">INSCRIRE USER</a></li>
<li><a href="#">VALIDER USER</a></li>
<li><a href="logs1.php" >STATS USER</a></li>
<li><a href="supprimeruser.php">SUPPRIMER USER</a></li>
<li><a href="desactiveruser.php">DESACTIVER USER</a></li>
<li><a href="modifieruser.php">MODIFIER USER</a></li>


</ul>
<br><br>