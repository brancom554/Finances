<?php


include('verification.php');
?>

<?php
include('menu2.php');


?>
<center>
<div id="global">
<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>

<?php



/*


if(!empty($_POST['pseudo']))
{
// D'abord, je me connecte � la base de donn�es.


// Je mets aussi certaines s�curit�s ici�
$passe = mysql_real_escape_string(htmlspecialchars($_POST['passe']));
$passe2 = mysql_real_escape_string(htmlspecialchars($_POST['passe2']));

if($passe == $passe2)
{
 //ajouter la suite du code en cas de reussite de la comparaison
 
 $pseudo = mysql_real_escape_string(htmlspecialchars($_POST['pseudo']));
$email = mysql_real_escape_string(htmlspecialchars($_POST['email']));
// Je vais crypter le mot de passe.
//$passe = sha1($passe);
mysql_query("INSERT INTO validation VALUES('', '$pseudo', '$passe', '$email')");

 
 
}
else
{
echo 'Les deux mots de passe que vous avez rentr�s ne correspondent pas�';
}
}

*/
?>




<?php
//On verifie que le formulaire a ete envoye
if(isset($_POST['pseudo'], $_POST['passe'], $_POST['passverif'], $_POST['email']) and $_POST['pseudo']!='')
{
	//On enleve lechappement si get_magic_quotes_gpc est active
	if(get_magic_quotes_gpc())
	{
		$_POST['pseudo'] = stripslashes($_POST['pseudo']);
		$_POST['passe'] = stripslashes($_POST['passe']);
		$_POST['passverif'] = stripslashes($_POST['passverif']);
		$_POST['email'] = stripslashes($_POST['email']);
		$_POST['acces'] = stripslashes($_POST['acces']);
		$_POST['nom_user'] = stripslashes($_POST['nom_user']);
		$_POST['prenom_user'] = stripslashes($_POST['prenom_user']);
		$_POST['telephone'] = stripslashes($_POST['telephone']);

	}
	//On verifie si le mot de passe et celui de la verification sont identiques
	if($_POST['passe']==$_POST['passverif'])
	{
		//On verifie si le mot de passe a 6 caracteres ou plus
		if(strlen($_POST['passe'])>=6)
		{
			//On verifie si lemail est valide
			if(preg_match('#^(([a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+\.?)*[a-z0-9!\#$%&\\\'*+/=?^_`{|}~-]+)@(([a-z0-9-_]+\.?)*[a-z0-9-_]+)\.[a-z]{2,}$#i',$_POST['email']))
			{
				//On echape les variables pour pouvoir les mettre dans une requette SQL
				$pseudo = mysql_real_escape_string($_POST['pseudo']);
				$passe = mysql_real_escape_string($_POST['passe']);
				$email = mysql_real_escape_string($_POST['email']);
				$acces = mysql_real_escape_string($_POST['acces']);
				$nom_user = mysql_real_escape_string($_POST['nom_user']);
				$prenom_user = mysql_real_escape_string($_POST['prenom_user']);
				$telephone= mysql_real_escape_string($_POST['telephone']);
				
				$dn = mysql_num_rows(mysql_query('select id from connexion where pseudo="'.$pseudo.'"'));
				if($dn==0)
				{
					//On recupere le nombre dutilisateurs pour donner un identifiant a lutilisateur actuel
					$dn2 = mysql_num_rows(mysql_query('select id from connexion'));
					$id = $dn2+1;
					//On enregistre les informations dans la base de donnee
				
		$query= mysql_query("insert into connexion values ('', '$pseudo', '$passe', '$email' ,'1','$acces','$nom_user','$prenom_user','$telephone','0')");
	                   if($query)
					{
						//Si ca a fonctionne, on naffiche pas le formulaire
						$form = false;
?>
<br />
<div class="message">Vous avez bien &eacute;t&eacute; inscrit. Vous pouvez dor&eacute;navant vous connecter .<br />
</div>
<?php
					}
					else
					{
						//Sinon on dit quil y a eu une erreur
						$form = true;
						$message = 'Une erreur est survenue lors de l\'inscription.';
					}
				
				}
				else
				{
					//Sinon, on dit que le pseudo voulu est deja pris
					$form = true;
					$message = 'Un autre utilisateur utilise d&eacute;j&agrave; le nom d\'utilisateur que vous d&eacute;sirez utiliser.';
				}
			
			}
			else
			{
				//Sinon, on dit que lemail nest pas valide
				$form = true;
				$message = 'L\'email que vous avez entr&eacute; n\'est pas valide.';
			}
		}
		else
		{
			//Sinon, on dit que le mot de passe nest pas assez long
			$form = true;
			$message = 'Le mot de passe que vous avez entr&eacute; contien moins de 6 caract&egrave;res.';
		}
	}
	else
	{
		//Sinon, on dit que les mots de passes ne sont pas identiques
		$form = true;
		$message = 'Les mots de passe que vous avez entr&eacute; ne sont pas identiques.';
	}
}
else
{
	$form = true;
}
if($form)
{
	//On affiche un message sil y a lieu
	if(isset($message))
	{
		echo '<div class="message">'.$message.'</div>';
	}
	//On affiche le formulaire
?>
<div><br />
<b>FORMULAIRE D'INSCRIPTION</b>
<br /><br />
    <form action="inscrire_membre.php" method="post">
        Veuillez remplir ce formulaire pour vous inscrire:<br />
        <table cellpadding="" cellspacing="" border="">
		<tr>
            <td><label for="pseudo">Nom d'utilisateur</label></td><td><input type="text" name="pseudo" value="<?php if(isset($_POST['pseudo'])){echo htmlentities($_POST['pseudo'], ENT_QUOTES, 'UTF-8');} ?>" /></td></tr>
           <tr> <td><label for="passe">Mot de passe<span class="small">(6 caract&egrave;res min.)</span></label></td><td><input type="password" name="passe" /></td></tr>
        <tr>    <td><label for="passverif">Mot de passe<span class="small">(v&eacute;rification)</span></label></td><td><input type="password" name="passverif" /></td></tr>
         <tr>   <td><label for="email">Email</label></td><td><input type="text" name="email" value="<?php if(isset($_POST['email'])){echo htmlentities($_POST['email'], ENT_QUOTES, 'UTF-8');} ?>" /></td></tr>
            <tr>
            <td><label for="acces">Niveau d'acces</label></td><td><select name="acces"><option value="1">Utilisateur</option>
			<option value="2">Administrateur</option></select>
			</td></tr>
			<tr>
			<td><label for="nom_user">NOM</label></td><td><input type="text" name="nom_user" /></td>
			</tr>
			<tr>
			<td><label for="prenom_user">PRENOM</label></td><td><input type="text" name="prenom_user" /></td>
			</tr>
			<tr>
			<td><label for="telephone">TELEPHONE</label></td><td><input type="text" name="telephone" /></td>
			</tr>
       <tr>   <td>  <input type="submit" value="Valider" /></td></tr>
	   </table>
	   
		</div>
    </form><br /><br />
</div>
<?php
}
?>


<br /><br />
<?php //include('footer.php') ; ?>
</body>

</html>
