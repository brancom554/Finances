<?php
session_start();
include('../../config.php');
echo'<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head></html>';
?>
<?php

@$pseudo=$_SESSION['pseudo'];
//session_start();

$date=date("Y-m-d");

//$req=mysql_query("SELECT * FROM log2 WHERE dateap='$date' AND pseudo='$pseudo' ");
//				  $req1=mysql_fetch_array($req);
	//			  $vendeur=$req1['pseudo'] ;
				  
if($pseudo=='')
{
echo 'Vous n\'etes pas connecte au site. Vous ne pouvez donc pas venir sur cette page.<br>';
echo'Cliquez <a href="../../index.php">ici</a> pour vous connecter';

exit;
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head>

<body>


</body>

</html>