<?php

include('verification.php');
?>

<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}

?>

<?php
include('menu4.php');

?>
<center>
<div id="global"><br /><br />
<?php
if(isset($_POST['Envoyer'])) {
if(isset($_POST['produit']))
$nom=$_POST['produit'];

if(isset($_POST['date1']))
$date1=datefrenus($_POST['date1']);

if(isset($_POST['date2']))
$date2=datefrenus($_POST['date2']);

echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom utilisateurs</td>';
					echo '<td>Date de connexion</td>';
	echo '</tr>';


				  
				  $query=mysql_query("SELECT * FROM log3  WHERE pseudo='$nom' AND dateap BETWEEN $date1 AND $date2 ");
					
					if($query) {
                     $n = mysql_num_rows($query);
                    
					 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"pseudo"); 
   $prixproduit=mysql_result($query,$i,"dateap"); 
   echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					echo '<td>'.$prixproduit.'</td>'; 
		echo '</tr>';        
									  }
							}
echo '</table>';
  }
  else{
?>

<?php
echo'<br><br><br>';
echo'<marquee><h3>PAGE DES LOGS </h3></marquee>';
echo'<br><br>';
echo'<center>';
echo'<legend>FAIRE DES RECHERCHES</legend>';
echo'<form action="" method="post">';
echo'<label>VEUILLEZ METTRE LE NOM DE L ADMINISTRATEUR</label>';?>

<select name="produit">

<?php

$query=mysql_query("SELECT * FROM connexion WHERE acces='2' ");
$data=mysql_num_rows($query);

for($i=0;$i<$data;$i++)
  {
  $nom=mysql_result($query,$i,"pseudo");
  
 echo' <option>'.$nom.' </option>';
	
  }
?>

	
	</select>
<?php
echo'&nbsp;<br><br>';
echo'<label>PERIODE ALLANT DE</label>&nbsp;<div style="width:500px; height:auto; font-size:small;">
	<div class="demo"> <input type="text" id="from" name="date1"  />&nbsp;<label>A</label>&nbsp;<input type="text" id="to" name="date2"  /></div></div><br><br>';
echo'<input type="submit" name="Envoyer" value="Rechercher" />';

echo'</center>';
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>
<body>

</body>
</html></div></center>
<br />
<?php include('footer.php')  ; ?>