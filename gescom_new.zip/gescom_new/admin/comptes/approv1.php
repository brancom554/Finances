<?php

include('verification.php');

				  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>
<body>
<?php
include('menu2.php');
echo'<br>';
?>
<center>
<div id="global">
<br />
<?php
if(isset($_GET['action']) )
{
$action = $_GET['action'];
$demande=mysql_query("select * from approvisionnement where dateap='$action' ")or die('Erreur sql:'.mysql_error());
$nombre=mysql_num_rows($demande);
echo'<br><b>LISTE DES APPROVISIONNEMENTS CONCERNANT LA DATE DU '.$action.'</b><br>';
echo'
<table>
<tr>
<td>ID</td><td>NOM ARTICLE</td><td>QUANTITE APPORTEE</td>
</tr>
';
for($l=0;$l<$nombre;$l++) {
      $id=mysql_result($demande,$l,"id");
	  $nomproduit=mysql_result($demande,$l,"nom");
	  $quantite=mysql_result($demande,$l,"quantite");
	  echo'<tr>';
	  echo'<td>'.$id.'</td>';
	  echo'<td>'.$nomproduit.'</td>';
	  echo'<td>'.$quantite.'</td>';
	  echo'</tr>';
       }
echo'</table><br><br><br>';
}

?>
</div></center>
</body>
</html>
<br />
<?php include('footer.php')  ; ?>