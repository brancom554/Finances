<?php

include('verification.php');
?>
<?php

include('menu2.php');
?>

<?php 
//R�cuperer les infos du formulaire

if(isset($_POST['Envoyer'])) {
if (isset($_POST['nom']))
$nom=$_POST['nom'];

if (isset($_POST['quantitedispo']))
$quantiteajoute=$_POST['quantitedispo'];
$date=date("Y-m-d");



			$req= mysql_query("SELECT pseudo FROM log WHERE dateap='$date'");
			if($req) {
			
			$dat=mysql_fetch_array($req,MYSQL_ASSOC);
                            $vendeur=$dat["pseudo"];
			         }
              

$query=mysql_query("SELECT quantitedispo FROM produit WHERE nom='$nom' ");
					
					if($query) {
                     //$n = mysql_num_rows($query);
                       $data=mysql_fetch_array($query,MYSQL_ASSOC);
                            $quantiterestant=$data["quantitedispo"]; 
							        
									  //}
					$quantitedispo= $quantiterestant + $quantiteajoute;
					//faire un update de l'enregistrement dans la table produit
					$requete= mysql_query("UPDATE produit SET prixvente='$quantiteajoute' WHERE nom='$nom' ");
					//if($requete)
					//echo 'OPERATION REUSSIE<br>';
					//header('Location:approvisionner.php');
					//$req= mysql_query("INSERT INTO journaldesprix() VALUES('','$nom','$quantitedispo','$vendeur','$date')");
					//if($req) echo'REUSSITE<br>';
                      //header('Location:changerprixdevente.php');
			        }
					
			}else
			header('Location:changerprixdevente.php');		
?>
</center>			

<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<br />
<center>
<div id="global">
<br>
<center>

&nbsp;&nbsp;&nbsp;&nbsp;<b>PRIX DE VENTE MODIFIE AVEC SUCCES</b>

</center>
<script type="text/javascript">
<!--
var obj = 'window.location.replace("changerprixdevente.php");';
setTimeout(obj,1000);
// -->
</script>
<br />
</div>
<br />
<?php include('footer.php'); ?>
</body>
</html>		