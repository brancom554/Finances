<?
session_start();
mysql_connect("localhost", "root", "");
mysql_select_db("gestion");

?>
<style type="text/css">
.generatecssdotcom_3d_53d8cdbf4ee0e {position:absolute;top:0;right:0;font-size:8px;color:#cccccc;} .generatecssdotcom_3d_53d8cdbf4ee0e a {color:#cccccc;text-decoration:none;font-weight:normal;} .generatecssdotcom_3d_53d8cdbf4ee0e a:hover {color:#cccccc;text-decoration:none;font-weight:normal;} 

.generatecssdotcom_text_53d8cdbf4ee0e {font-size: 80px;font-family: Georgia;color: #609f9f;font-weight: bold;font-style: italic;text-shadow:0 1px 0 #ccc, 0 2px 0 #c9c9c9,0 3px 0 #bbb, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15);} 
</style> 



<span class="generatecssdotcom_text_53d8cdbf4ee0e">&nbsp;BIENVENUE SUR GESCOM </span>
<br>

<?php
/*
if(isset($_POST['pseudo']))
$pseudo=$_POST['pseudo'];

if(isset($_POST['passe']))
$passe=$_POST['passe'];

mysql_connect("localhost", "root", "");
mysql_select_db("gestion");
$pseudo = mysql_real_escape_string(htmlspecialchars($_POST['pseudo']));
$passe = mysql_real_escape_string(htmlspecialchars($_POST['passe']));
// Je crypte $passe avec la fonction "sha1".
$passe = sha1($passe);
$nbre = mysql_query("SELECT COUNT(*) AS exist FROM connexion WHERE pseudo='$pseudo'");
$donnees = mysql_fetch_array($nbre);
if($donnees['exist'] != 0) // Si le pseudo existe.
{
$quete = mysql_query("SELECT * FROM connexion WHERE pseudo='$pseudo'");
$infos = mysql_fetch_array($quete);
if($passe == $infos['passe'])
{
// C'est ici que je mets le code servant à effectuer la connexion, car le mot de passe est bon.
//on dirige vers la page des utilisateurs
$_SESSION['pseudo']=$pseudo;
header('Location:membres/index.php');
}
else // Si le couple pseudo/ mot de passe n'est pas bon.
{
echo 'Vous n\'avez pas rentré les bons identifiants<br>';

}
}
?>﻿
<?php

echo '<form action="" method="post">';
echo'<label>Pseudo: <input type="text" name="pseudo"/></label><br/>';
echo '<label>Mot de passe: <input type="password" name="passe"/></label><br/>';

echo '<input type="submit" value="M\'inscrire"/>';
echo'</form>';
*/
?>






<?php
//Si lutilisateur est connecte, on le deconecte
/*
if(isset($_SESSION['pseudo']))
{
	//On le deconecte en supprimant simplement les sessions username et userid
	unset($_SESSION['pseudo'], $_SESSION['userid']);
?>

<div>Vous avez bien &eacute;t&eacute; d&eacute;connect&eacute;.<br />
<a href="<?php echo $url_home; ?>">Accueil</a></div>

<?php
}
else
{*/
?>

<?php
	$ousername = '';
	//On verifie si le formulaire a ete envoye
	if(isset($_POST['pseudo'], $_POST['passe']))
	{
		//On echappe les variables pour pouvoir les mettre dans des requetes SQL
		if(get_magic_quotes_gpc())
		{
			$ousername = stripslashes($_POST['pseudo']);
			$pseudo = mysql_real_escape_string(stripslashes($_POST['pseudo']));
			$passe = stripslashes($_POST['passe']);
			$_SESSION['user']=$pseudo;
		}
		else
		{
			$pseudo = mysql_real_escape_string($_POST['pseudo']);
			$passe = $_POST['passe'];
			$_SESSION['user']=$passe;
		}
		//On recupere le mot de passe de lutilisateur
		mysql_connect("localhost", "root", "");
        mysql_select_db("gestion");

		$req = mysql_query("select passe,id from connexion where pseudo='$pseudo' AND statut='1' AND acces='2'");
		$dn = mysql_fetch_array($req);
		//On le compare a celui quil a entre et on verifie si le membre existe
		if($dn['passe']==$passe and mysql_num_rows($req)>0)
		{
			//Si le mot de passe es bon, on ne vas pas afficher le formulaire
			$form = false;
			//On enregistre son pseudo dans la session username et son identifiant dans la session userid
			$_SESSION['pseudo'] = $_POST['pseudo'];
			$_SESSION['userid'] = $dn['id'];
			$_SESSION['toto2']=$_POST['pseudo'];
			$date=date("Y-m-d");
			$req= mysql_query("INSERT INTO log2() VALUES('','$pseudo','$date')");
			$req1= mysql_query("INSERT INTO log3() VALUES('','$pseudo','$date')");
					//if($req) echo'REUSSITE<br>';
			header("Location:admin/index.php");
?>




<?php
		}
		else
		{
			//Sinon, on indique que la combinaison nest pas bonne
			$form = true;
			$message = 'La combinaison que vous avez entr&eacute; n\'est pas bonne.';
		}
	}
	else
	{
		$form = true;
	}
	if($form)
	{
		//On affiche un message sil y a lieu
	if(isset($message))
	{
		echo '<div class="message">'.$message.'</div>';
	}
	//On affiche le formulaire
?>
<br><br>
<center>
<div id="global">
<br>

<center>
<br>
       <center> <b>Veuillez entrer vos identifiants pour vous connecter:</b></center><br />
<form action="connexion2.php" method="post">
        <table>
		<tr>
            <td><label for="pseudo">Nom d'utilisateur</label></td><td><input type="text" name="pseudo" id="pseudo" value="<?php echo htmlentities($ousername, ENT_QUOTES, 'UTF-8'); ?>" /></td></tr>
			<tr>
            <td><label for="passe">Mot de passe</label></td><td><input type="password" name="passe" id="passe" /></td></tr>
            <tr>
			<td colspan="1"> </td><td><input type="submit" value="Connection" /></td></tr>
		</table>
    </form>
</center>
<?php
	}
//}
?>






<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">


</head>
<body>
<br><br>

</body>
</html>﻿
</div>
</center><br><br>
<?php
include('footer.php');
?>