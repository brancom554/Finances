<?php
include('config.php');
?>



<?php

/* 
session_start();
$_SESSION['Pseudo'] = '';
$_SESSION['Passe'] = '';

if(isset($_POST['envoyer']))
  {
  echo 'SALUT A TOUS';
   if(isset($_POST['Pseudo']) && !empty($_POST['Pseudo']) && isset($_POST['Passe']) && !empty($_POST['Passe'])) {
$Pseudo=(isset($_POST['Pseudo'])) ? $_POST['Pseudo']: '' ;
$Passe=(isset($_POST['Passe'])) ? $_POST['Passe']: '' ;

//Nouvel ajout
$base = mysql_connect("localhost","root","007jam");
mysql_select_db("ftp");
$sql=" SELECT count(*) FROM utilisateur WHERE Pseudo = '$Pseudo' AND Passe = '$Passe' ";
$req = mysql_query($sql) or die('Erreur sql!');
$data = mysql_fetch_array($req);
mysql_free_result($req);
mysql_close();
//si il ya une réponse c'est que l'utilisateur existe
  if($data[0]==1) {
//   session_start();
   $_SESSION['Pseudo']= $_POST['Pseudo'];
  header('location:service.php');
//echo "sa marche";
   exit();
   }
    elseif($data[0]==0){
     echo " Compte non reconnu<br>";
      }

     else {
     echo " PROBLEME:plusieurs membres ont les memes identifiants<br>";
         }

   }   

  }

/*
     if(($Pseudo=="admin") && ($Passe=="root"))
      {

      $_SESSION['Pseudo']="admin";
      $_SESSION['Passe']="root";
       
      echo '<a href="service.php" title="Aller a la page des services">Accueil</a><br>';
      echo'';
      echo'<a href="deconnexion.php">Deconnexion</a><br>';
      
      }
      
     else
    { 
    echo '<p style= "color:#FF000;font-weight:bold;">Erreur de connexion.</p>';
    }*/   
  
/*
if(!isset($_POST['envoyer']))
  {
 echo'<form id="conn" method="post" action="login.php"><br>';
 echo'<p><label for="Pseudo">Pseudo:</label><input type="text" name="Pseudo"></p><br>';
 echo'<p><label for="Passe">Passe:</label>&nbsp;&nbsp;<input type="password" name="Passe"></p><br>';
 echo'<p><input type="submit" name="envoyer" value="connexion"></p><br>';
 echo'</form><br>';
  }

*/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>ESPACE Clients</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="mm_travel2.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("January","February","March","April","May","June","July","August","September","October","November","December");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
</head>
<body bgcolor="#C0DFFD">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr bgcolor="#3366CC">
    <td width="382" colspan="3" rowspan="2"><img src="mm_travel_photo.jpg" alt="Header image" width="382" height="127" border="0" /></td>
    <td width="378" height="63" colspan="3" id="logo" valign="bottom" align="center" nowrap="nowrap">JAMES ENTERPRISE </td>
    <td width="100%">&nbsp;</td>
  </tr>

  <tr bgcolor="#3366CC">
    <td height="64" colspan="3" id="tagline" valign="top" align="center">D&eacute;veloppons notre pays </td>
	<td width="100%">&nbsp;</td>
  </tr>

  <tr>
    <td colspan="7" bgcolor="#003366"><img src="mm_spacer.gif" alt="" width="1" height="1" border="0" /></td>
  </tr>

  <tr bgcolor="#CCFF99">
  	<td colspan="7" id="dateformat" height="25">&nbsp;&nbsp;<script language="JavaScript" type="text/javascript">
      document.write(TODAY);	</script>	</td>
  </tr>
 <tr>
    <td colspan="7" bgcolor="#003366"><img src="mm_spacer.gif" alt="" width="1" height="1" border="0" /></td>
  </tr>

 <tr>
    <td width="165" valign="top" bgcolor="#E6F3FF">
	<table border="0" cellspacing="0" cellpadding="0" width="165" id="navigation">
        <tr>
          <td width="165">&nbsp;<br />
		 &nbsp;<br /></td>
        </tr>
        <tr>
          <td width="165"><a href="index.html" class="navText">ACCUEIL</a></td>
        </tr>
        <tr>
          <td width="165"><a href="partenaire.php" class="navText">PARTENAIRES</a></td>
        </tr>
        <tr>
          <td width="165"><a href="login.php" class="navText">ESPACE CLIENTS</a></td>
        </tr>
        <tr>
          <td width="165"><a href="inscription.php" class="navText">INSCRIPTION</a></td>
        </tr>
        
        <tr>
          <td width="165"><a href="contact.html" class="navText">CONTACTS</a></td>
        </tr>
      </table>
 	�<br />
  	&nbsp;<br />
  	&nbsp;<br />
  	&nbsp;<br /> 	</td>
    <td width="50"><img src="mm_spacer.gif" alt="" width="50" height="1" border="0" /></td>
    <td width="305" colspan="2" valign="top"><img src="mm_spacer.gif" alt="" width="305" height="1" border="0" /><br />
	&nbsp;<br />
	&nbsp;<br />
	<table border="0" cellspacing="0" cellpadding="0" width="305">
        <tr>
          <td class="pageName">TRANSFERT FICHIERS JAMES ENTERPRISE</td>
		</tr>

		<tr>
          <td class="bodyText"><p>Simplifiez vos transferts de fichiers

Exp�diez en quelques clics vos fichiers volumineux sur un serveur s�curis�.

Chaque destinataire re�oit par email un lien de t�l�chargement.<br />
En vous inscrivant,vous ne perdez plus vos donnees juste apres 24heures
<br><br><br>



<?php
//Si lutilisateur est connecte, on le deconecte
if(isset($_SESSION['username']))
{
	//On le deconecte en supprimant simplement les sessions username et userid
	unset($_SESSION['username'], $_SESSION['userid']);
?>

<div>Vous avez bien &eacute;t&eacute; d&eacute;connect&eacute;.<br />
<a href="<?php echo $url_home; ?>">Accueil</a></div>

<?php
}
else
{
	$ousername = '';
	//On verifie si le formulaire a ete envoye
	if(isset($_POST['username'], $_POST['password']))
	{
		//On echappe les variables pour pouvoir les mettre dans des requetes SQL
		if(get_magic_quotes_gpc())
		{
			$ousername = stripslashes($_POST['username']);
			$username = mysql_real_escape_string(stripslashes($_POST['username']));
			$password = stripslashes($_POST['password']);
		}
		else
		{
			$username = mysql_real_escape_string($_POST['username']);
			$password = $_POST['password'];
		}
		//On recupere le mot de passe de lutilisateur
		$req = mysql_query('select password,id from users where username="'.$username.'"');
		$dn = mysql_fetch_array($req);
		//On le compare a celui quil a entre et on verifie si le membre existe
		if($dn['password']==$password and mysql_num_rows($req)>0)
		{
			//Si le mot de passe es bon, on ne vas pas afficher le formulaire
			$form = false;
			//On enregistre son pseudo dans la session username et son identifiant dans la session userid
			$_SESSION['username'] = $_POST['username'];
			$_SESSION['userid'] = $dn['id'];
?>

<div >Vous avez bien &eacute;t&eacute; connect&eacute;. Vous pouvez acc&eacute;der &agrave; votre espace membre.<br />
<a href="service.php">Acceder au menu des applications</a></div>

<?php
		}
		else
		{
			//Sinon, on indique que la combinaison nest pas bonne
			$form = true;
			$message = 'La combinaison que vous avez entr&eacute; n\'est pas bonne.';
		}
	}
	else
	{
		$form = true;
	}
	if($form)
	{
		//On affiche un message sil y a lieu
	if(isset($message))
	{
		echo '<div class="message">'.$message.'</div>';
	}
	//On affiche le formulaire
?>


<form action="login.php" method="post">
        Veuillez entrer vos identifiants pour vous connecter:<br />
        
            <label for="username">Nom d'utilisateur</label><input type="text" name="username" id="username" value="<?php echo htmlentities($ousername, ENT_QUOTES, 'UTF-8'); ?>" /><br />
            <label for="password">Mot de passe</label><input type="password" name="password" id="password" /><br />
            <input type="submit" value="Connection" />
		
    </form>

<?php
	}
}
?>

</p>

		<p>


</p></td>
        </tr>
      </table>
	  �<br />	  </td>
    <td width="50"><img src="mm_spacer.gif" alt="" width="50" height="1" border="0" /></td>
        <td width="190" valign="top"><br />
		&nbsp;<br />
		<table border="0" cellspacing="0" cellpadding="0" width="190">
			<tr>
			<td colspan="3" class="subHeader" align="center">NEW DESTINATIONS</td>
			</tr>

			<tr>
			<td width="40"><img src="mm_spacer.gif" alt="" width="40" height="1" border="0" /></td>
			<td width="110" id="sidebar" class="smallText"><br />
			<p><img src="mm_travel_photo1.jpg" alt="Image 1" width="110" height="110" vspace="6" border="0" /><br />
			Include a short description here.<br />
			<a href="javascript:;">Read more &gt;</a></p>

			<p><img src="mm_travel_photo2.jpg" alt="Image 2" width="110" height="110" vspace="6" border="0" /><br />
			Include a short description here.<br />
			<a href="javascript:;">Read more &gt;</a></p>
			�<br />
			&nbsp;<br />
			&nbsp;<br />			</td>
			<td width="40">&nbsp;</td>
			</tr>
		</table>	</td>
	<td width="100%">&nbsp;</td>
  </tr>
  <tr>
    <td width="165">&nbsp;</td>
    <td width="50">&nbsp;</td>
    <td width="167">&nbsp;</td>
    <td width="138">&nbsp;</td>
    <td width="50">&nbsp;</td>
    <td width="190">&nbsp;</td>
	<td width="100%">&nbsp;</td>
  </tr>
</table>
</body>
</html>
