<?php
require_once('periodeconfig.php');

//if(empty($debut) && empty($fin)) {
				  
set_time_limit(0);      /*permet au script de s'exécuter indéfiniment */

ignore_user_abort(1);//ignorer la fermeture du navigateur


				
?>

<html>

<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">

<style type="text/css">
p{ font-family: Arial,sans-serif; 
font-size: 1.6em; 
width: 200px; 
height: 43px;
 padding-top: 7px; /*permet le centrage vertical*/ 
 text-align: center; 
 color:#CC3366; 
 background:#33CCFF; 
 
 background: -webkit-linear-gradient( #555DEF, #2C2C2C); 
 background: -moz-linear-gradient( #555DEF, #2C2C2C); 
 background: -ms-linear-gradient( #555DEF, #2C2C2C); 
 background: -o-linear-gradient( #555DEF, #2C2C2C); 
 background: linear-gradient( #555DEF, #2C2C2C); 
 border-radius: 8px;
text-shadow: 0px 1px 0px rgba( 255, 255, 255, 0.2);
box-shadow: 0 0 5px rgba( 0, 0, 0, 0.5), 0 -1px 0 rgba( 255, 255, 255, 0.4);
 
 }
 
 p:active{ color: #CC3366; background: #33CCFF; background: -webkit-linear-gradient( #555, #2C2C2C); background: -moz-linear-gradient( #555, #2C2C2C); background: -ms-linear-gradient( #555, #2C2C2C); background: -o-linear-gradient( #555, #2C2C2C); background: linear-gradient( #555, #2C2C2C); box-shadow: 1px 1px 10px black inset, 0 1px 0 rgba( 255, 255, 255, 0.4); }
 
 p:hover{ color: #222; background: #555; background: -webkit-linear-gradient( #777, #333); background: -moz-linear-gradient( #777, #333); background: -ms-linear-gradient( #777, #333); background: -o-linear-gradient( #777, #333); background: linear-gradient( #777, #333); }
 
 .generatecssdotcom_3d_53d8cdbf4ee0e {position:absolute;top:0;right:0;font-size:8px;color:#cccccc;} .generatecssdotcom_3d_53d8cdbf4ee0e a {color:#cccccc;text-decoration:none;font-weight:normal;} .generatecssdotcom_3d_53d8cdbf4ee0e a:hover {color:#cccccc;text-decoration:none;font-weight:normal;} 

.generatecssdotcom_text_53d8cdbf4ee0e {font-size: 80px;font-family: Georgia;color: #609f9f;font-weight: bold;font-style: italic;text-shadow:0 1px 0 #ccc, 0 2px 0 #c9c9c9,0 3px 0 #bbb, 0 4px 0 #b9b9b9, 0 5px 0 #aaa, 0 6px 1px rgba(0,0,0,.1), 0 0 5px rgba(0,0,0,.1), 0 1px 3px rgba(0,0,0,.3), 0 3px 5px rgba(0,0,0,.2), 0 5px 10px rgba(0,0,0,.25), 0 10px 10px rgba(0,0,0,.2), 0 20px 20px rgba(0,0,0,.15);} 
</style> 

</head>
<body>

<center>
	<span class="generatecssdotcom_text_53d8cdbf4ee0e">&nbsp;BIENVENUE SUR GESCOM </span>

<center>
<div id="global">
<br><br>
<b>CLIQUER SUR LE BOUTON CI-DESSOUS POUR VOUS CONNECTER</b><br><br><br><br>
<p><a href="connexion.php"><blink>CONNEXION</blink></a></p>&nbsp;&nbsp;<br /><br><br><br>
</center>

<center>

</center>
</div>
</center>

<?php
include('footer.php');
?>

</body>

</html>﻿