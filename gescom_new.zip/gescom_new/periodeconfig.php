<?php
include('config.php');
set_time_limit(0);      /*permet au script de s'ex�cuter ind�finiment */

ignore_user_abort(1);//ignorer la fermeture du navigateur



//$table[]='';				
				
				
				
				//on recup�re la date et l'heure actuels

$aNow = date("Y");

        $mNow = date("m");

        $jNow = date("d");

        $hNow = date("H");

        $minNow = date("i");
$debut=mktime($hNow, $minNow, 0, $mNow, $jNow, $aNow);

//on calcule la date de fin
$a = date("Y");

        $m= date("m");

        $j = date("d")+60;

        $h = date("H");

        $min = date("i");
$fin=mktime($h, $min, 0, $m, $j, $a);
//je stocke la fin dans $_SESSION et je fais un controle sur chaque page concern�e

//on fabrique la date de fin
$date_fin=date("Y",$fin).'-'.date("n", $fin).'-'.date("d",$fin);

//je fait un select de la table periode
$req=mysql_query("SELECT * FROM periode");
if($req)
   {
   $req1=mysql_num_rows($req);
      if($req1 <1)
	  $query=mysql_query("INSERT INTO periode() VALUES ('','$debut','$fin') ");
	  else
	  echo '';
   }




?>