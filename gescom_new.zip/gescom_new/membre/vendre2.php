<?php
session_start();
//include('verification.php');
echo'<div class="bouton">
<ul>
<a href="#">ACCUEIL</a>
<a href="deconnexion.php">SE DECONNECTER</a>
<a href="vendre.php">VENDRE</a>
<a href="approvisionner.php">APPROVISIONNER PRODUITS</a>
<a href="stock.php">VOIR STOCK</a>
<a href="voir_vente.php">RAPPORT DU JOUR</a>

</ul>

</div>';

?>


<?php

$tail=sizeof($_SESSION['quantitepro']);
//echo $tail;


$link= mysql_connect('localhost', 'root', '');
               if (!$link) 
			   {
              die('Impossible de se connecter : ' . mysql_error());
               }
             if (!mysql_select_db('gestion')) 
			      {
                die('Impossible de slectionner la table : ' . mysql_error());
                  }

for($i=0;$i<$tail;$i++)
      {
$quantiteproduit=$_SESSION['quantitepro'][$i];
$nomproduit=$_SESSION['tableau'][$i];
$prixproduit=$_SESSION['prixproduit'][$i];

//$vendeur="albann";

$date=date("Y-m-d");

$req=mysql_query("SELECT * FROM log WHERE dateap='$date'");
				  $req1=mysql_fetch_array($req);
				  $vendeur=$req1['pseudo'] ;
				  
//pour mettre a jour le stock
					$query=mysql_query("SELECT quantitedispo FROM produit WHERE nom='$nomproduit' ");
					
					if($query) {
                     $n = mysql_num_rows($query);
                    for($j=0;$j<$n;$j++) {
                            $quantitedispo=mysql_result($query,$j,"quantitedispo"); 
							        
									  //}
					$quantitedisp=$quantitedispo - $quantiteproduit;
					//faire un update de l'enregistrement dans la table produit
					$requete= mysql_query("UPDATE produit SET quantitedispo='$quantitedisp' WHERE nom='$nomproduit' ");
					if($requete)
					echo 'OPERATION REUSSIE<br>'; }
			        }
					
			//inserer dans calculer_ventes
			$result = mysql_query("INSERT INTO calculer_ventes(id,nomproduit,prixproduit,vendeur,quantiteproduit,datevente) VALUES ('','$nomproduit','$prixproduit','$vendeur','$quantiteproduit','$date') ");
              if (!$result) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }
			  else {
			       echo 'Insertion reussie<br>';
				   }		
					
	}	
?>				


<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<br><br><br>
<center>
<div id="affiche">

<p align="center"><blink><h3>Vous allez �tre redirig� dans quelques secondes!!!</h3></blink></p>

</div>



</center>
<script type="text/javascript">
<!--
var obj = 'window.location.replace("vendre.php");';
setTimeout(obj,2000);
// -->
</script>
</body>
</html>