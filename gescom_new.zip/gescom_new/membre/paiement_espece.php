<?php include('../config.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />

		<title>Page Paiement</title>

		
        <link rel="stylesheet" type="text/css" media="screen" href="style.css" />
		
		


<script type="text/javascript">

function verifForm(f)
{
   var ageOk = verifAge(f.num_client);
   var age3Ok = verifAge3(f.nom_client);
    
   
   if(ageOk && age2Ok && age3Ok)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}

function verifAge(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 61000000 || age > 99999999)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}

function verifAge2(champ)
{

   var age = parseInt(champ.value);
   if(isNaN(age) || age < 0 || age > 10000000)
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}


function verifAge3(champ)
{

   var age =champ.value;
   if(age=="" )
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}


function verifAge4(champ)
{

   var age = champ.value;
   if(age=="" )
   {
      surligne(champ, true);
	  alert("ATTENTION A VOS VALEURS ");
      return false;
   }
   else
   {
      surligne(champ, false);
      return true;
   }
}
</script>
	</head>
	<body>
	

<?php include('menu1.php') ; ?>
<br><br>
<center>
<div id="global">

<?php

include('fiche_client.php');

?>
<br /><br />

</div>
</center>
<br />
<?php include('footer.php')  ; ?>