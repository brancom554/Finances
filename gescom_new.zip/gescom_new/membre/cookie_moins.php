<?php
include('../config.php');

$panier = $_COOKIE["panier"];
if(isset($_GET["moins"])){
@$panier["moins"]--;
setCookie("panier[moins]",$panier["moins"]);
$nom=$_GET['moins'];



$req=mysql_query("SELECT * FROM panier WHERE nomproduit='$nom' ")or die('Erreur sql pour la mise a jour');
$donnee=mysql_fetch_array($req);
$quant=$donnee["Quantiteproduit"];
$prix=$donnee["prixunitaire"];
$prixtotal=$donnee["prixtotal"];
$ajout=$quant - 1;
$sup=$prixtotal - $prix;

mysql_query("UPDATE panier SET quantiteproduit='$ajout' WHERE nomproduit='$nom' ")or die('Erreur sql pour la mise a jour');
mysql_query("UPDATE panier SET Prixtotal='$sup' WHERE nomproduit='$nom' ")or die('Erreur sql pour la mise a jour');

header('Location:vendre.php');

                         }

?>