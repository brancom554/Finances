<?php
session_start();
include('../config.php');
$pseudo=$_SESSION['pseudo'];
//mysql_connect("localhost", "root", "");
//mysql_select_db("gestion");
mysql_query("UPDATE connexion SET connecte='0' WHERE pseudo='$pseudo' ") or die('Erreur sql:'.mysql_error());

//si pas de vente mettre la date dans calculer_ventes
$date=date("Y-m-d");
$heure=date("H:i");

$query=mysql_query("select * from calculer_ventes where datevente='$date' and vendeur='$pseudo' ") or die('Erreur sql:'.mysql_error());
$query1=mysql_num_rows($query);
if($query1 ==0)
mysql_query("insert into calculer_ventes values('','NEANT','0','$pseudo','0','$date','','$heure')") or die('erreur sql'.mysql_error());

//$req=mysql_query("delete from log where pseudo='$pseudo' ");
session_unset();
session_destroy();
 header('location:../index.php');

?>