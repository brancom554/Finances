<?php
include('verification.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head>

<body>

<?php include('menu1.php') ; ?><br />
<center>
<div id="global">
<br /><br />
<center><b>BIENVENUE CHER UTILISATEUR</b></center><br />
<b>GESCOM </b>est un outil sp�cialement con�u pour les TPE, PME-PMI de
tous secteurs d�activit�s.<br /> Vous souhaitez g�rer et ma�triser votre circuit complet de vente et
d�achat dans un seul logiciel, <br />cr�er un catalogue d�articles d�taill� avec photos si  possible, <br />�tre au plus pr�s des r�glements et des relances clients, <br />suivre l��tat de vos stocks et les ventes op�r�es dans la journ�e pour voir si cela colle avec votre caisse.<br /><br />
</div>
</center>
<br />
<?php include('footer.php') ; ?>
</body>
</html>