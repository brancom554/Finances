<?php
	$id_facture=rand(1,10000);
	$_SESSION['facture']=$id_facture;
	
	echo'<center>
	  <b>INFOS CLIENT </b>
	</center><br><br><br>';
	echo'<center><b>Facture Numero:'.$id_facture.'</b></center>';?>
	<form action="invoice/facture.php" method="post"  onSubmit="return verifForm(this)">
	<table>
	<tr>
	<td>Nom Client</td><td><input type="text" name="nom_client" onblur="verifAge3(this)"></td>
	</tr>
	<tr>
	<td>Telephone Client</td><td><input type="text" name="num_client" onblur="verifAge(this)"></td>
	</tr>
	
	<tr>
	<td>Categorie Sociale</td><td><select name="categorie_sociale"><option selected="Veuillez choisir"></option>
	<option>Informatique</option><option>Sante</option><option>Administration</option><option>Enseignement</option><option>Electricite</option><option>Finance</option><option>ONG</option></select>
	</td>
	</tr>
	<tr>
	<td>TVA</td><td><select name="tva" > <option value="0.18">Oui</option><option value="0">Non</option> </select></td>
	</tr>
	<tr>
	<td>Notes sur les achats</td><td><textarea name="commentaire" ></textarea></td>
	</tr>
	
	</table>
	<input type="submit" name="Envoyer" value="Soumettre" />
	
	</form>
	<br />
	<a href="index.php">RETOUR A L'ACCUEIL</a><br />