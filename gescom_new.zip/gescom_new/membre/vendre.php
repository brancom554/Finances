﻿<?php
//session_start();
include('verification.php');
//include('alerte.php');
include('cookie_init.php');
//$_SESSION['tableau'][]=

$_SESSION['nomarticle']='alban';
if(!empty($_SESSION['tableau'])){
foreach ($_SESSION['tableau'] as $i => $value) {
    unset($_SESSION['tableau'][$i]);
}
        }

?>

<?php
include('menu1.php');
echo '<br>';

//echo '<br>';
//echo'<br><br><br><br><br>';
?>
<center>
<div id="global">
<br><br>
<form action="" method="post">
<table>
<tr>
<td><input type="text" name="quantite"></td>
<td><select name="nom" >
<option selected="selected">Choisir les Articles</option>

<?php
$query=mysql_query("SELECT * FROM produit");
$data=mysql_num_rows($query);
for($i=0;$i<$data;$i++)
 {
 $nom=mysql_result($query,$i,"nom");
 $_SESSION['nomarticle']=mysql_result($query,$i,"prixvente");
$quantitedispo=mysql_result($query,$i,"quantitedispo");
 echo'<option>'.$nom.'</option>';
 
 }

?>
</select></td>
<input type="hidden" name="name" value="<?php echo $nom ?>">
<td><input type="submit"  name="Envoyer" value="Ajouter au panier"></td>
</tr>
</table>
</form>
<br><br>
<?php
if(isset($_POST['Envoyer']) && $_POST['nom'] != "Choisir les Articles" ){
//echo'ON avvvvvv';
$nom=$_POST['nom'];
if (@preg_match('#^([^0-9]+)([0-9]+)$#',$nom,$decomposition_partie))        
$nom1=$decomposition_partie[1];
//$nom1=explode(':',$nom1);
//$nom1=stripslashes($nom1[0]);
$quantite=$_POST['quantite'];
//echo $_POST['name'];
echo'<br>';

$question=mysql_query("SELECT prixvente FROM produit WHERE nom='$nom'  ")or die('impossible d executer votre requete.Le produit choisi n\'est pas disponible');
//Ajouter une condition pour eviter de vendre les produits dont le stock est 0
if($question) {
$prixu=$data["prixvente"];
          $total=$prixu * $quantite;
$requete=mysql_query("SELECT quantitedispo FROM produit WHERE nom='".$nom."' ");
     if($requete) {
	       $donnee=mysql_fetch_array($requete);
		   $donnee1=$donnee['quantitedispo'];
		   if($donnee1 == 0 ) {
		   echo '<b>Le produit recherche n est plus disponible</b><br><br>';exit(0);}
		   else
		   $data=mysql_fetch_array($question);
		   
		   if($donnee1<$quantite)  {
		  		   echo '<b>La quantite demandee pour ce  produit  n est pas disponible</b><br><br>';exit(0);}
				   else  
		   $data=mysql_fetch_array($question);
		   
		                          }
			
			
	      }
		  

		  
		  
		            
//$data=mysql_fetch_array($question);
//}

//var_dump($data);
//pour essai
			$question=mysql_query("SELECT prixvente FROM produit WHERE nom='$nom'  ")or die('impossible d executer votre requete.Le produit choisi n\'est pas disponible');					  
		   $data=mysql_fetch_array($question) or die("nous avons des drap");
		   $prixu=$data["prixvente"];
            $total=$prixu * $quantite;

$req=mysql_query("SELECT * FROM panier WHERE nomproduit='$nom' ")or die('impossible d executer votre requete');
$req1=mysql_num_rows($req);

if($req1==0)
mysql_query("INSERT INTO panier VALUES('','$nom','$quantite','$prixu','$total')")or die('Erreur verifier 3 de la table');
//mysql_query("INSERT INTO panier2 VALUES('','$nom','$quantite','$prixu','$total')")or die('Erreur verifier 3 de la table');


else{
$req=mysql_query("SELECT * FROM panier WHERE nomproduit='$nom' ")or die('Erreur sql pour la mise a jour');
$donnee=mysql_fetch_array($req);
$quant=$donnee["Quantiteproduit"];
$prixu=$donnee["prixunitaire"];
$total=$donnee["prixtotal"];
$supplement=$quantite * $prixu ;
$supplement1=$supplement + $total;
$ajout=$quant + $quantite;
mysql_query("UPDATE panier SET quantiteproduit='$ajout' WHERE nomproduit='$nom' ")or die('Erreur sql pour la mise a jour');
mysql_query("UPDATE panier SET prixtotal='$supplement1' WHERE nomproduit='$nom' ")or die('Erreur sql pour la mise a jour');

}
    }
$grand_total=0;

?>
<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<style type="text/css">
#contenu {
			padding: 0 32px 0 25px;
            float: right;
			background-color:#CC0000;
		}

		#contenu p {
			margin: 0px;

		}

</style>
</head>
<body>



<br><br>
<b>MES ACHATS</b>
<?php include('panier.php') ?>
</center>
<br>
<?php include('footer.php')  ;?>
</body>
</html>