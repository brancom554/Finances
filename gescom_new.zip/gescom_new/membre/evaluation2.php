<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head>

<body>
<br /><br /><br />
<marquee><h2>VOUS N'ETES PLUS AUTORISE A VOIR CETTE PAGE.MERCI DE BIEN VOULOIR ACTIVER VOTRE VERSION</h2></marquee>
<hr />
<br /><br />
</body>

</html>