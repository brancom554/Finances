<?php 

include('../config.php');

$query=mysql_query("SELECT * FROM produit ") or die('Impossible d executer la requete');
$donnees=mysql_num_rows($query);
for($i=0;$i<$donnees;$i++)
{
$nom=mysql_result($query,$i,"nom");
@setCookie("panier[$nom]", 0); 
}
 //header("Location: cookie_ajout.php");
?>