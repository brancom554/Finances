<?php
session_start();
include('verification.php');
?>
<?php
echo'<div class="bouton">
<ul>
<a href="#">ACCUEIL</a>
<a href="deconnexion.php">SE DECONNECTER</a>
<a href="vendre.php">VENDRE</a>
<a href="approvisionner.php">APPROVISIONNER PRODUITS</a>
<a href="stock.php">VOIR STOCK</a>
<a href="voir_vente.php">RAPPORT DU JOUR</a>

</ul>

</div><br><br><br><br><br><br><br>';

?>

<?php
if(isset($_POST['envoyer']) ) {
$prixproduit=0;
$grandtotal = 0;
//$id=$_SESSION['idprod_$i'];
$taille=$_SESSION['compteur'];
echo $taille;
echo '<form action="compta_vente.php" method="post">';
echo '<table border="5" cellpadding="2" cellspacing="2" >';
echo'<tr height="10">';
echo'<td>ID</td>';
echo'<td> NOM PRODUIT </td>';
echo '<td>QUANTITE</td>'; 
echo '<td>Prix Unitaire</td>';
echo '<td>Somme due</td>';
echo '</tr>';


$i=0;
//for($i=0;$i<$taille;$i=$i+1)
    while($i<$taille)                         {
//echo 'mon i est '.$i;
$nomproduit=$_SESSION['tableau'][$i];
//$nomproduit=$_SESSION['nomproduit'. $i .''];
//echo $nomproduit;
//$nomproduit="banane2";
//$quantiteproduit=23;
//$prixproduit=25;
if (isset($_POST['quantiteproduit'. $i .'']))
$quantiteproduit=$_POST['quantiteproduit'. $i .''];
//echo 'ALLO ALLO'.$quantiteproduit;
$_SESSION['quantitepro'][$i]=$quantiteproduit;

if (isset($_POST['prixproduit'. $i .'']))
$prixproduit=$_POST['prixproduit'. $i .''];
$_SESSION['prixproduit'][$i]=$prixproduit;
/*
if (isset($_POST['quantiteproduit0']))
$quantiteproduit=$_POST['quantiteproduit0'];

if (isset($_POST['prixproduit0']))
$prixproduit=$_POST['prixproduit0'];
*/
//$vendeur="albann";

$date=date("Y-m-d");

if (isset($_POST['balance'. $i .'']))
$prixbalance=$_POST['balance'. $i .''];
//connexion base de donnees

$link= mysql_connect('localhost', 'root', '');
               if (!$link) 
			   {
              die('Impossible de se connecter : ' . mysql_error());
               }
             if (!mysql_select_db('gestion')) 
			      {
                die('Impossible de slectionner la table : ' . mysql_error());
                  }
				  
				  $req=mysql_query("SELECT * FROM log WHERE dateap='$date'");
				  $req1=mysql_fetch_array($req);
				  $vendeur=$req1['pseudo'] ;
				  $_SESSION['technico']=$vendeur;
				  
				  if (isset($_POST['balance'. $i .'']) && !empty($_POST['balance'. $i .''])) {
$prixbalance=$_POST['balance'. $i .''];
$prixunitaire=$prixbalance;
$total = $prixbalance * $quantiteproduit;
                                  }
else {
//selection du prix unitaire d'un produit donn�			  
$query=mysql_query("SELECT prixvente FROM produit WHERE nom='$nomproduit' ");
					
					if($query) {
					//echo'Requete effectuee<br>';
                     $n = mysql_num_rows($query);
                    for($j=0;$j<$n;$j++) {
                            $prixunitaire=mysql_result($query,$j,"prixvente");
					                     } 
								}
$total = $prixunitaire * $quantiteproduit;
           }
echo'<tr height="10">';
                   echo'<td>'.$i.'</td>';
                   echo'<td>'.$nomproduit.'</td>';
                    echo '<td>'.$quantiteproduit.'</td>'; 
					echo '<td>'.$prixunitaire.'</td>'; 
                   echo '<td>'.$total.'</td>';
                    echo '</tr>';
					$grandtotal=$total + $grandtotal;
					$i=$i+1;
					$quantiteproduit='';
					}
					echo '<tr>';
					echo '<td></td>';
					echo '<td>COUT TOTAL</td>';
					echo '<td>'.$grandtotal.'</td>';
					echo '</tr>';
					echo'</table>';
?>

<?php

echo'<br><br><br><br>';
echo'<a href="vendre2.php">cliquer ici pour finaliser la vente</a><br>';
}
?>
<?php
//echo'<marquee><h3>VOUS N AVEZ ENCORE RIEN CHOISI COMME PRODUIT.VEUILLEZ BIEN LE FAIRE AU MENU VENDRE</h3></marquee>';
?>
<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>

</body>
</html>