<?php
//session_start();
include('verification.php');


?>

<?php
include('menu1.php');
echo'<br>';

?>
<center>
<div id="global">
<?php
function datefrenus($datefr)
{
if (!$datefr) return "";
list($jour, $mois, $annee) = explode("/", $datefr);
$dateus = $annee."-".$jour."-".$mois;
return $dateus;
}
$vente_total=0;
?>

<?php

$dates=date("Y-m-d");

//$req=mysql_query("SELECT * FROM log WHERE dateap='$dates'");
			//	  $req1=mysql_fetch_array($req);
			//	  $vendeur=$req1['pseudo'] ;
$vendeur=$_SESSION['pseudo'];

//$vendeur=$_SESSION['technico'];
//echo $vendeur;
echo'<br><br><center><b>VOS VENTES DU JOUR</b></center><br>';
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					echo '<td>Prix Produit</td>';
					echo '<td>Vendeur</td>'; 
                   echo '<td>Quantite</td>';
				   echo '<td>Somme des ventes</td>';
				   //echo '<td>DATE</td>';
				   echo'<td>Heure de la ventes</td>';
                    echo '</tr>';


				  
				  $query=mysql_query("SELECT * FROM calculer_ventes WHERE datevente='$dates' AND vendeur='$vendeur' ORDER BY nomproduit");
					
					if($query) {
					
                     $n = mysql_num_rows($query);
                    
					 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
 $heurevente=mysql_result($query,$i,"heurevente");
 
 //Selection du prix pour le calcul des ventes
 $req=mysql_query("SELECT prixvente FROM produit WHERE nom='$nomproduit' ");
 $req1=mysql_fetch_array($req);
 $prixvente=$req1['prixvente'];
 //calcul de la somme des ventes
 $sommevente=$quantiteproduit * $prixvente;
 $vente_total=$sommevente + $vente_total;
 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					echo '<td>'.$prixvente.'</td>'; 
					echo '<td>'.$vendeur.'</td>'; 
                   echo '<td>'.$quantiteproduit.'</td>';
				   echo '<td>'.$sommevente.'</td>';
				   //echo'<td>'.$date.'</td>';
				   echo'<td>'.$heurevente.'</td>';
                    echo '</tr>';        
									  }
							}

echo'<tr>';
echo'<td></td><br>';
//echo'<td></td>';
echo'<td>TOTAL </td>';
echo '<td>'.$vente_total.'</td>';
echo'</tr>';
echo '</table>';
									  
?>			

</div>
</center>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>VOIR VENTES 2</title>
</head>

<body>
<br><br>
<?php include('footer.php') ; ?>
</body>
</html>
						  