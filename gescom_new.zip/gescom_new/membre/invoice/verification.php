<?php
require('evaluation.php');
echo'<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head></html>';
?>
<?php




//on recup�re la date et l'heure actuels
/*
$aNow = date("Y");

        $mNow = date("m");

        $jNow = date("d");

        $hNow = date("H");

        $minNow = date("i")+1;
$dateactu=mktime($hNow, $minNow, 0, $mNow, $jNow, $aNow);


$debut='';
$fin='';
$req=mysql_query("SELECT * FROM periode LIMIT 1");
$req1=mysql_fetch_array($req);
                       if($req1){
                           $debut=$req1['debut'];
                            $fin=$req1['fin'];
							
							}

if($debut<=$dateactu && $dateactu<=$fin){
$rest=$fin - $debut;
$jj=$rest/86400;
echo'Il vous reste'.$jj.'jours<br>';}
else header('evaluation2.php');
//session_start();

*/



$date=date("Y-m-d");





@$pseudo=$_SESSION['pseudo'];
//session_start();

$date=date("Y-m-d");

//$req=mysql_query("SELECT count(*) AS nombre FROM log WHERE dateap='$date' AND pseudo='$pseudo' ");
				//  $req1=mysql_fetch_array($req);
				//  $vendeur=$req1['nombre'] ;
				  
if($pseudo == '')
{
echo 'Vous n\'etes pas connecte au site. Vous ne pouvez donc pas venir sur cette page.<br>';
echo'Cliquez <a href="../index.php">ici</a> pour vous connecter';
exit;
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css"> 
<title></title>
</head>

<body>


</body>

</html>