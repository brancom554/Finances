<?php
@session_start();
@include('config.php');
//set_time_limit(0);      /*permet au script de s'ex�cuter ind�finiment */

//ignore_user_abort(1);//ignorer la fermeture du navigateur



$debut='';
$fin='';
$req=mysql_query("SELECT * FROM periode LIMIT 1");
@$req1=mysql_fetch_array($req);
                       if($req1){
                           $debut=$req1['debut'];
                            $fin=$req1['fin'];
							//echo $debut;
							//echo'<br>';
							//echo $fin;
							
							
				//on recup�re la date et l'heure actuels

$aNow = date("Y");

        $mNow = date("m");

        $jNow = date("d");

        $hNow = date("H");

        $minNow = date("i");
$actuel=mktime($hNow, $minNow, 0, $mNow, $jNow, $aNow);			
							
							if($debut<=$actuel) {
							if($actuel<=$fin) {
$rest=$fin - $actuel;
$jj=$rest/86400;
/*
echo'<table>';
echo'<tr><td>';
echo'Il vous reste&nbsp;'.$jj.'jours';
echo'</td></tr>';
echo'</table>';
//echo'Il vous reste '.$rest.'secondes<br><br>'; */

}
else {
	echo'VOTRE TEMPS D UTILISATION EST ARRIVE A EXPIRATION<br>';
	header('Location:evaluation2.php'); 
	}
 }
	
	
							}
							
				/*			
				if(empty($debut) && empty($fin)) {
				  
				
				
				echo'brbrbr';
				
				//on recup�re la date et l'heure actuels

$aNow = date("Y");

        $mNow = date("m");

        $jNow = date("d");

        $hNow = date("H");

        $minNow = date("i");
$debut=mktime($hNow, $minNow, 0, $mNow, $jNow, $aNow);

//on calcule la date de fin
$a = date("Y");

        $m= date("m");

        $j = date("d");

        $h = date("H");

        $min = date("i")+3;
$fin=mktime($h, $min, 0, $m, $jNow, $a);
//je stocke la fin dans $_SESSION et je fais un controle sur chaque page concern�e

//on fabrique la date de fin
$date_fin=date("Y",$fin).'-'.date("n", $fin).'-'.date("d",$fin);

$query=mysql_query("INSERT INTO periode() VALUES ('','$debut','$fin') ");

//$fini=mktime(date("H",$fin),date("i",$fin),0,date("n", $fin),date("d",$fin),date("Y",fin));
echo $date_fin;
				
				}			/*
							if($debut==''){
//Controler la periode d'essai




  }*/

?>	