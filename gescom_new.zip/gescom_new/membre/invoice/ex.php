<?php
mysql_connect('localhost','root','');
mysql_select_db('gestion');
// (c) Xavier Nicolay
// Exemple de génération de devis/facture PDF

require('invoice.php');
@set_magic_quotes_runtime(false);
ini_set('magic_quotes_runtime', 0);
@$nom_client=$_POST['nom_client'];
@$num_client=$_POST['num_client'];
@$categorie_sociale=$_POST['categorie_sociale'];
@$tva=$_POST['tva'];
@$reglement='Paiement Especes';
@$id_facture=rand(1,10000);
$date=date("Y-m-d H:i");


$pdf = new PDF_Invoice( 'P', 'mm', 'A4' );
$pdf->AddPage();
$pdf->addSociete( "MaSociete",
                  "MonAdresse\n" .
                  "229 BOHICON\n".
                  "R.C.N. B 000 000 007\n" .
                  "Capital : 1000 " . EURO );
//$pdf->fact_dev( "DEVIS ", "FACTURE" );
$pdf->temporaire( "Devis temporaire" );
//$pdf->addDate( "$date");
$pdf->addClient("$id_facture");
//$pdf->addPageNumber("1");
$pdf->addClientAdresse("M.$nom_client \n N°Telephone:$num_client\n \n ");
$pdf->addReglement("$reglement");
//$pdf->addEcheance("30/07/2014");
//$pdf->addNumTVA("FR888777666");
//$pdf->addReference("Devis ... du ....");
$cols=array( "REFERENCE"    => 23,
             "DESIGNATION"  => 78,
             "QUANTITE"     => 22,
             "P.U. HT"      => 26,
             "MONTANT H.T." => 30,
             "TVA"          => 11 );
$pdf->addCols( $cols);
$cols=array( "REFERENCE"    => "L",
             "DESIGNATION"  => "L",
             "QUANTITE"     => "C",
             "P.U. HT"      => "R",
             "MONTANT H.T." => "R",
             "TVA"          => "C" );
$pdf->addLineFormat( $cols);
$pdf->addLineFormat($cols);

$y    = 109;



for($a=0;$a<2;$a++)
     {
	 
	 //Ajout d'articles à la facture
$var=mysql_query("SELECT * FROM panier where nomproduit='bonbon'");
$nb=mysql_fetch_array($var);
	 
	 $nomproduit=$nb["nomproduit"];
	 $quantiteproduit=$nb["Quantiteproduit"];
	 $prixunitaire=$nb["prixunitaire"];
	 $total=$nb["prixtotal"];
	 
$line = array( "REFERENCE"    => "REF",
               "DESIGNATION"  => "$nomproduit \n" .
                                 "\n" .
                                 "",
               "QUANTITE"     => "$quantiteproduit",
               "P.U. HT"      => "$prixunitaire",
               "MONTANT H.T." => "$total",
               "TVA"          => "1" );
$size = $pdf->addLine( $y, $line );
$y   += $size + 2;
  }
$line = array( "REFERENCE"    => "REF2",
               "DESIGNATION"  => "Câble RS232",
               "QUANTITE"     => "1",
               "P.U. HT"      => "10.00",
               "MONTANT H.T." => "60.00",
               "TVA"          => "1" );
$size = $pdf->addLine( $y, $line );
$y   += $size + 2;

$pdf->addCadreTVAs();
        
// invoice = array( "px_unit" => value,
//                  "qte"     => qte,
//                  "tva"     => code_tva );
// tab_tva = array( "1"       => 19.6,
//                  "2"       => 5.5, ... );
// params  = array( "RemiseGlobale" => [0|1],
//                      "remise_tva"     => [1|2...],  // {la remise s'applique sur ce code TVA}
//                      "remise"         => value,     // {montant de la remise}
//                      "remise_percent" => percent,   // {pourcentage de remise sur ce montant de TVA}
//                  "FraisPort"     => [0|1],
//                      "portTTC"        => value,     // montant des frais de ports TTC
//                                                     // par defaut la TVA = 19.6 %
//                      "portHT"         => value,     // montant des frais de ports HT
//                      "portTVA"        => tva_value, // valeur de la TVA a appliquer sur le montant HT
//                  "AccompteExige" => [0|1],
//                      "accompte"         => value    // montant de l'acompte (TTC)
//                      "accompte_percent" => percent  // pourcentage d'acompte (TTC)
//                  "Remarque" => "texte"              // texte
$tot_prods = array(array ( "px_unit" => "$prixunitaire"/655, "qte" => "$quantiteproduit", "tva" => 1 ),
                   array ( "px_unit" =>  10/655, "qte" => 1, "tva" => 1 ));
$tab_tva = array( "1"       => "$tva",
                  "2"       => "$tva");
$params  = array( "RemiseGlobale" => 1,
                      "remise_tva"     => 1,       // {la remise s'applique sur ce code TVA}
                      "remise"         => 0,       // {montant de la remise}
                      "remise_percent" => 10,      // {pourcentage de remise sur ce montant de TVA}
                  "FraisPort"     => 0,
                      "portTTC"        => 0,      // montant des frais de ports TTC
                                                   // par defaut la TVA = 19.6 %
                      "portHT"         => 0,       // montant des frais de ports HT
                      "portTVA"        => 0.18,    // valeur de la TVA a appliquer sur le montant HT
                  "AccompteExige" => 1,
                      "accompte"         => 0,     // montant de l'acompte (TTC)
                      "accompte_percent" => 15,    // pourcentage d'acompte (TTC)
                  "Remarque" => "Avec un acompte, svp..." );

$pdf->addTVAs( $params, $tab_tva, $tot_prods);
$pdf->addCadreEurosFrancs();
/*
Pour enregistrer les factures dans un dossier
$CheminFichier = str_replace("\\", "/", $_SERVER['DOCUMENT_ROOT'])."/../EditionsPDF/MonDocument.pdf";
 $pdf->Output($CheminFichier,'F'); // enregistre le pdf

*/
//mysql_query('TRUNCATE panier') or die('Erreur de traitement sql');
$pdf->Output("$nom_client.pdf",'');
header('Location:../paiement_espece.php');
?>


