<?php include('verification.php'); ?>
<style type="text/css">
#cadre{
width:500px;
height:auto;
background-color:#CCCCCC;
-webkit-border-radius: 4px 4px 6px 6px;
 border-radius: 2px 2px 3px 3px;
 
 
 -webkit-box-shadow: inset 1px 1px 3px 3px #2020a6; box-shadow: inset 1px 1px 3px 3px #2020a6; 

}

table {
border-color:white;
border-style:solid;
border-width:1px;
}
td {
font-family:verdana, sans-serif;
font-size:100%;
color:black;
text-align:left;
background-color:transparent;
border-color:white;
border-style:solid;
border-width:1px;
}

</style>
<br><br>
<?php
if(isset($_POST['Envoyer']) && !empty($_POST['nom_client']) && !empty($_POST['num_client']) ) {
@$nom_client=$_POST['nom_client'];
@$num_client=$_POST['num_client'];
@$categorie_sociale=$_POST['categorie_sociale'];
@$tva=$_POST['tva']; 
?>
<center>
<div id="cadre"><br /><br />
 
<p>
<p align="left">
&nbsp;&nbsp;SOCIETE JAMES ENTERPRISE<br>
&nbsp;&nbsp;BP: 109 BOHICON<br />
&nbsp;&nbsp;TEL:96966767<br>
&nbsp;&nbsp;RC N:089-A 
</p>
<p align="right">
<?php echo $nom_client; ?>&nbsp;&nbsp;<br>
<?php echo 'TEL:&nbsp;'.$num_client; ?>&nbsp;&nbsp;<br />
</p>
</p>
<br><br />
<?php 
$date=date("Y-m-d H:i");
//echo $date;?>
<br><br /><br />
<p align="left">
<table>
<tr><td>CODE CLIENT</td><td>MODE DE REGLEMENT</td><td>Date et heure d'achat</td><td>TYPE CLIENT</td></tr>
<tr><td><?php echo rand(1,3500); ?></td><td>ESPECES</td><td><?php echo $date;  ?></td><td>CLIENTS DIVERS</td></tr>
</table></p>

<br /><br /><br />
<table border="1">
<tr >
<td>Articles</td>
<td>Quantite</td>
<td>Prix Unitaire</td>
<td>Montant TVA</td>
<td>Total</td> 

</tr>

<?php

$grand_total=0;
$total=0;
$total_tva=0;
$net_a_payer=0;
$heurevente=date("H:i-2") ;

$query=mysql_query("SELECT * FROM panier  order by nomproduit") or die('Impossible d executer la requete');
$donnees=mysql_num_rows($query);
for($i=0;$i<$donnees;$i++)
{
$nom=mysql_result($query,$i,"nomproduit");
$quantite=mysql_result($query,$i,"quantiteproduit");
$prixu=mysql_result($query,$i,"prixunitaire");
$total=mysql_result($query,$i,"prixtotal");
//$tva= 0.00 ;
echo'<tr>
<td>'.$nom.'</td>
<td>'.$quantite.'</td>
<td>'.$prixu.'</td>
<td>'.$tva * $prixu.'</td>
<td>'.$total.'</td></tr>';
$grand_total=$grand_total + $total;
$total_tva=$total_tva + $tva * $prixu;
//heurevente de calculer_ventes
//$demande=mysql_query("Select heurevente FROM calculer_ventes where ='$nom' ") or die('Erreur sql:'.mysql_error());
//$demande1=mysql_fetch_array($demande);
}
echo'</table><table><tr>
<td colspan="2"></td><td colspan="1" >TOTAL T.V.A.</td><td>'.$total_tva.'</td></tr>
<tr>
<td colspan="2"></td><td colspan="1" >TOTAL H.T.</td><td>'.$grand_total.'</td></tr>
<tr>
<td colspan="2"></td><td colspan="1" >NET A PAYER</td><td>'.$grand_total + $total_tva.'</td></tr>
</table>';

?>
<br /><br />
<p align="center">
<table>
<td colspan="2"></td><td colspan="1" >TOTAL T.V.A.</td><td><?php echo $total_tva; ?></td></tr>
<tr>
<td colspan="2"></td><td colspan="1" >TOTAL H.T.</td><td><?php echo $grand_total; ?></td></tr>
<tr>
<td colspan="2"></td><td colspan="1" >NET A PAYER</td><td><?php echo $grand_total + $total_tva; ?></td></tr>
</table>
</p>
<?php
//include('../panier.php');


echo '<br><br>';

$query=mysql_query('SELECT pseudo FROM log');
$data=mysql_fetch_array($query);
$nom2=$_SESSION['pseudo'];
echo'<p align="right">';
echo'<b>LE CAISSIER</b>&nbsp;<br>';
echo $nom2;
echo'&nbsp;';
echo'</p>';
echo'<br><br>';
$req=mysql_query("INSERT INTO facture VALUES ('','$nom_client','$num_client','$categorie_sociale','$date','$nom2','$grand_total','$heurevente') ")or die('Erreur sql:'.mysql_error());
if($req)  {
echo'<center>APPUYER SUR CTRL+P POUR IMPRIMER LA FACTURE</center><br>';
mysql_query("TRUNCATE panier");
?>

<script type="text/javascript">
<!--
var obj = 'window.location.replace("../vendre.php");';
setTimeout(obj,24000);
// -->
</script>

<?php
}
}
?>
<hr />
<br /><br />
TOUT ARTICLE VENDU N'EST NI REPRIS NI ECHANGE<br />
<u>SOCIETE JAMES ENTERPRISE</u><br />
N�RC:N�1824<br />
N�INSAE:xxxxxxxxxxxx &nbsp;<br />
Email:entreprise@gmail.com<br />
BOHICON-BENIN<br /><br /><br>

</div>
</center>
