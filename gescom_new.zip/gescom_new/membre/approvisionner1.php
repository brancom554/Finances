<?php

include('verification.php');
?>
<?php

include('menu1.php');
?>
<br />
<center>
<div id="global">
<?php 
//R�cuperer les infos du formulaire

if(isset($_POST['Envoyer'])) {
if (isset($_POST['nom']))
$nom=$_POST['nom'];

if (isset($_POST['quantitedispo']))
$quantiteajoute=$_POST['quantitedispo'];
$date=date("Y-m-d");



			$req= mysql_query("SELECT pseudo FROM log WHERE dateap='$date'");
			if($req) {
			
			$dat=mysql_fetch_array($req,MYSQL_ASSOC);
                            $vendeur=$dat["pseudo"];
			         }
              

$query=mysql_query("SELECT quantitedispo FROM produit WHERE nom='$nom' ");
					
					if($query) {
                     //$n = mysql_num_rows($query);
                       $data=mysql_fetch_array($query,MYSQL_ASSOC);
                            $quantiterestant=$data["quantitedispo"]; 
							        
									  //}
					$quantitedispo= $quantiterestant + $quantiteajoute;
					//faire un update de l'enregistrement dans la table produit
					$requete= mysql_query("UPDATE produit SET quantitedispo='$quantitedispo' WHERE nom='$nom' ");
					//if($requete)
					//echo 'OPERATION REUSSIE<br>';
					//header('Location:approvisionner.php');
					$req= mysql_query("INSERT INTO approvisionnement() VALUES('','$nom','$quantiteajoute','$vendeur','$date')");
					//if($req) echo'REUSSITE<br>';

			        }
					
			}else
			header('Location:approvisionner.php');		
?>
</center>			

<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">
</head>
<body>
<br>
<p align="center">
&nbsp;&nbsp;&nbsp;&nbsp;<h2>STOCK AJOUTE AVEC SUCCES</h2>
</p>
<script type="text/javascript">
<!--
var obj = 'window.location.replace("approvisionner.php");';
setTimeout(obj,3000);
// -->
</script>
<br />
<?php include('footer.php'); ?>
</body>
</html>		