
<br><br><br><br>


<table>
<tr>
<td>Articles</td>
<td>Quantite</td>
<td>Prix Unitaire</td>
<td>Total</td> 
<td>Actions</td>
</tr>

<?php 
$_GET['moins']='';
$grand_total=0;
$total=0;

$query=mysql_query("SELECT * FROM panier  order by nomproduit") or die('Impossible d executer la requete');
$donnees=mysql_num_rows($query);


for($i=0;$i<$donnees;$i++)
{
$nom=mysql_result($query,$i,"nomproduit");
$quantite=mysql_result($query,$i,"quantiteproduit");
$prixu=mysql_result($query,$i,"prixunitaire");
$total=mysql_result($query,$i,"prixtotal");
echo'<tr>
<td>'.$nom.'</td>
<td>'.$quantite.'</td>
<td>'.$prixu.'</td>
<td>'.$total.'</td>
<td><a href="cookie_ajout.php?ajout='.$nom.'" ><b>+</b></a>&nbsp;<a href="cookie_moins.php?moins='.$nom.'"><b>-</b></a>&nbsp; <a href="cookie_sup.php?supprimer='.$nom.' "><b>x</b></a></td> 
</tr>';
$grand_total=$grand_total + $total;
}
echo'<tr>
<td colspan="3"></td><td>TOTAL</td><td>'.$grand_total.'</td>
</tr>
</table>';


//on fait les traitements en fonction des boutons appuy�s

if(isset($_POST['supprimer'])){
myqsl_query("DELETE  * FROM panier WHERE nomproduit='$nom'");

}

echo'<br><br>';
echo'<a href="fin_vente.php">CLIQUER ICI POUR FINALISER LA VENTE</a><br><br><br>';
?>