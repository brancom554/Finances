<?php
include('../config.php');

$panier = $_COOKIE["panier"];
if(isset($_GET["supprimer"])){
//@$panier[""]--;
//setCookie("panier[moins]",$panier["moins"]);
$nom=$_GET['supprimer'];



$req=mysql_query("DELETE FROM panier WHERE nomproduit='$nom' ") or die('Erreur sql pour la mise a jour');


header('Location:vendre.php');

                         }

?>