<?php
//session_start();
include('verification.php');
?>
<?php
include('menu1.php');
echo'<br>';

?>
<center>
<div id="global">
<br />
<center>
&nbsp;&nbsp;&nbsp;&nbsp;<a href="voir_vente1.php" > CLIQUER ICI POUR VOIR LES VENTES DU JOUR</a>
	</center
><?php
/*
echo '<table border="5" cellpadding="2" cellspacing="2" >';
                   echo'<tr height="10">';
                   
                   echo'<td> ID</td>';
                    echo '<td>Nom produit</td>';
					echo '<td>Prix Produit</td>';
					echo '<td>Vendeur</td>'; 
                   echo '<td>Quantite</td>';
				   echo '<td>DATE</td>';
                    echo '</tr>';
					
					
				$query=mysql_query("SELECT * FROM calculer_ventes ");
				if (!$query) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }	
					
              
					
					else {
  $n =mysql_num_rows($query);
 for($i=0;$i<$n;$i++) {
 
  $id=mysql_result($query,$i,"id"); 
   $nomproduit=mysql_result($query,$i,"nomproduit"); 
   $prixproduit=mysql_result($query,$i,"prixproduit"); 
   $vendeur=mysql_result($query,$i,"vendeur"); 
 $quantiteproduit=mysql_result($query,$i,"quantiteproduit"); 
 $date=mysql_result($query,$i,"datevente");
 echo'<tr height="10">';
                   
                   echo'<td>'.$id.'</td>';
                    echo '<td>'.$nomproduit.'</td>'; 
					echo '<td>'.$prixproduit.'</td>'; 
					echo '<td>'.$vendeur.'</td>'; 
                   echo '<td>'.$quantiteproduit.'</td>';
				   echo'<td>'.$date.'</td>';
                    echo '</tr>';        
									  }
									  
							}
									  
echo '</table>';

*/
?>
</div>
</center>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="style.css" rel="stylesheet" media="all" type="text/css">
<title>VOIR VENTES</title>

<link rel="stylesheet" type="text/css" href="jquery-ui.css">
		<link rel="stylesheet" type="text/css" href="demos.css">
		<script src="CALENDRIER/jquery-1.5.1.js"></script>
		<script src="CALENDRIER/jquery.ui.core.js"></script>
		<script src="CALENDRIER/jquery.ui.widget.js"></script>
		<script src="CALENDRIER/jquery.ui.datepicker.js"></script>
		<script> 
			$(function() {
				var dates = $( "#from, #to" ).datepicker({
					defaultDate: "+1w",
					changeMonth: true,
					numberOfMonths: 1,
					onSelect: function( selectedDate ) {
						var option = this.id == "from" ? "minDate" : "maxDate",
							instance = $( this ).data( "datepicker" ),
							date = $.datepicker.parseDate(
								instance.settings.dateFormat ||
								$.datepicker._defaults.dateFormat,
								selectedDate, instance.settings );
						dates.not( this ).datepicker( "option", option, date );
					}
				});
			});
		</script> 

</head>

<body>
<br /><br />

	
	<center>
	<?php include('footer.php') ; ?>
	
	</center>
	
</body>
</html>
