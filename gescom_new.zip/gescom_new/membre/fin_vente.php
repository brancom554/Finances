<?php
@session_start();
include('verification.php');


$demande=mysql_query("SELECT * FROM panier");
$nbre=mysql_num_rows($demande);
for($d=0;$d<$nbre;$d++) 
      {
$quantiteproduit=mysql_result($demande,$d,"Quantiteproduit");
$nomproduit=mysql_result($demande,$d,"nomproduit");
$prixproduit=mysql_result($demande,$d,"prixunitaire");
      //}

$date=date("Y-m-d");

//$req=mysql_query("SELECT * FROM log WHERE dateap='$date'");
				 // $req1=mysql_fetch_array($req);
				  //$vendeur=$req1['pseudo'] ;
				 $vendeur=$_SESSION['pseudo']; 
//pour mettre a jour le stock
					$query=mysql_query("SELECT quantitedispo FROM produit WHERE nom='$nomproduit' ");
					
					if($query) {
                     $n = mysql_num_rows($query);
                    for($j=0;$j<$n;$j++) {
                            $quantitedispo=mysql_result($query,$j,"quantitedispo"); 
							        
									  //}
					$quantitedisp=$quantitedispo - $quantiteproduit;
					//faire un update de l'enregistrement dans la table produit
					$requete= mysql_query("UPDATE produit SET quantitedispo='$quantitedisp' WHERE nom='$nomproduit' ");
					if($requete)
					echo ''; }
			        }
					$heurevente=date("H:i");
			//inserer dans calculer_ventes
			$result = mysql_query("INSERT INTO calculer_ventes(id,nomproduit,prixproduit,vendeur,quantiteproduit,datevente,statut,heurevente) VALUES ('','$nomproduit','$prixproduit','$vendeur','$quantiteproduit','$date','1','$heurevente') ");
              if (!$result) 
			  {
               die('Impossible d\'excuter la requte :' . mysql_error());
              }
			  else {
			       echo '';
				   }		
					
	}	
?>				


<html>
<head>
<link href="style.css" rel="stylesheet" media="all" type="text/css">

<style type="text/css">
p{ font-family: Arial,sans-serif; 
font-size: 1.6em; 
width: 200px; 
height: 43px;
 padding-top: 7px; /*permet le centrage vertical*/ 
 text-align: center; 
 color:#CC3366; 
 background:#33CCFF; 
 
 background: -webkit-linear-gradient( #555DEF, #2C2C2C); 
 background: -moz-linear-gradient( #555DEF, #2C2C2C); 
 background: -ms-linear-gradient( #555DEF, #2C2C2C); 
 background: -o-linear-gradient( #555DEF, #2C2C2C); 
 background: linear-gradient( #555DEF, #2C2C2C); 
 border-radius: 8px;
text-shadow: 0px 1px 0px rgba( 255, 255, 255, 0.2);
box-shadow: 0 0 5px rgba( 0, 0, 0, 0.5), 0 -1px 0 rgba( 255, 255, 255, 0.4);
 
 }
 
 p:active{ color: #CC3366; background: #33CCFF; background: -webkit-linear-gradient( #555, #2C2C2C); background: -moz-linear-gradient( #555, #2C2C2C); background: -ms-linear-gradient( #555, #2C2C2C); background: -o-linear-gradient( #555, #2C2C2C); background: linear-gradient( #555, #2C2C2C); box-shadow: 1px 1px 10px black inset, 0 1px 0 rgba( 255, 255, 255, 0.4); }
 
 p:hover{ color: #222; background: #555; background: -webkit-linear-gradient( #777, #333); background: -moz-linear-gradient( #777, #333); background: -ms-linear-gradient( #777, #333); background: -o-linear-gradient( #777, #333); background: linear-gradient( #777, #333); }
 
</style>
</head>
<body>

<?php include('menu1.php'); ?>
<br><br>
<center>
<div id="global">

<br><br>

<center><b>VEUILLEZ CHOISIR VOTRE FACON DE PAYER!!!</b></center>
<br />
<center>
<p><a href="paiement_electronique.php">Electronique</a></p>&nbsp;&nbsp;<p><a href="paiement_espece.php">Especes</a></p>
</center>
<br>
</div>


</center>
<br>

      
      <br /><br /><br />
    
 &nbsp;        
    <div style="background-position:bottom; font-size:8px;">
	<center><b>COPYRIGHT Marius A.GANHOUEGNON,JAMES ENTERPRISE 2014 (C)  </b></center></div>

</body>
</html>