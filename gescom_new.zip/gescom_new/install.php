<?php

$link= mysql_connect('localhost', 'root', '');
               if (!$link) 
			   {
              die('Impossible de se connecter : ' . mysql_error());
               }
             if (!mysql_select_db('gestion')) 
			      {
                die('Impossible de slectionner la table : ' . mysql_error());
                  }


echo'INSTALLATION DES TABLES<br><br>';
//ici le fichier qui contient l install des bases de donn�es et de toutes les tables 
$query=mysql_query("CREATE TABLE `validation` (
`id` INT( 255 ) NOT NULL AUTO_INCREMENT ,
`pseudo` VARCHAR( 255 ) NOT NULL ,
`passe` VARCHAR( 255 ) NOT NULL ,
`email` VARCHAR( 255 ) NOT NULL ,
INDEX ( `id` )
)");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"

$query=mysql_query("CREATE TABLE `validation2` (
`id` INT( 255 ) NOT NULL AUTO_INCREMENT ,
`pseudo` VARCHAR( 255 ) NOT NULL ,
`passe` VARCHAR( 255 ) NOT NULL ,
`email` VARCHAR( 255 ) NOT NULL ,
INDEX ( `id` )
)");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"


$query=mysql_query("CREATE TABLE `connexion` (
`id` INT( 255 ) NOT NULL AUTO_INCREMENT ,
`pseudo` VARCHAR( 255 ) NOT NULL ,
`passe` VARCHAR( 255 ) NOT NULL ,
`email` VARCHAR( 255 ) NOT NULL ,
PRIMARY KEY(id)
)
");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"

$query=mysql_query("CREATE TABLE `connexion2` (
`id` INT( 255 ) NOT NULL AUTO_INCREMENT ,
`pseudo` VARCHAR( 255 ) NOT NULL ,
`passe` VARCHAR( 255 ) NOT NULL ,
`email` VARCHAR( 255 ) NOT NULL ,
PRIMARY KEY(id)
)");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"

$query=mysql_query("");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"


$query=mysql_query("CREATE TABLE approvisionnement(id int(4) NOT NULL auto_increment,nom VARCHAR(250) NOT NULL,quantite VARCHAR(250) NOT NULL,vendeur VARCHAR(255) NOT NULL dateap date,PRIMARY KEY(id))");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"

$query=mysql_query("CREATE TABLE log(id int(4) NOT NULL auto_increment,pseudo VARCHAR(250) NOT NULL,dateap date,PRIMARY KEY(id))");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"


$query=mysql_query("CREATE TABLE log2(id int(4) NOT NULL auto_increment,pseudo VARCHAR(250) NOT NULL,dateap date,PRIMARY KEY(id))");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"

$query=mysql_query("CREATE TABLE log3(id int(4) NOT NULL auto_increment,pseudo VARCHAR(250) NOT NULL,dateap date,PRIMARY KEY(id))");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"

$query=mysql_query("CREATE TABLE periode(id int(3) NOT NULL auto_increment,debut int(6) NOT NULL,fin int(6) NOT NULL,PRIMARY KEY(id))");
if($query)
echo "REQUETE EFFECTUEE AVEC SUCCES<br>"


$query=mysql_query("create table produit(ref text(5),nom varchar(20),quantitedispo int(5),prixachat int(5),prixvente int(5),benefice int(5),dateappro date,PRIMARY KEY(nom))");
if($query)
echo'REQUETE EFFECTUEE AVEC SUCCES<br>';

$query=mysql_query("CREATE TABLE `proceder_ventes` (
  `id` bigint(20) NOT NULL auto_increment,
  `nomproduit` varchar(255) NOT NULL,
  PRIMARY KEY(id))");
if($query)
echo'REQUETE EFFECTUEE AVEC SUCCES<br>';

$query=mysql_query("CREATE TABLE `calculer_ventes` (
  `id` bigint(20) NOT NULL auto_increment,
  `nomproduit` varchar(255) NOT NULL,
   `prixproduit` int(20) NOT NULL,
 `vendeur` varchar(255) NOT NULL,
 `quantiteproduit` int(20) NOT NULL,
  PRIMARY KEY(id))");
if($query)
echo'REQUETE EFFECTUEE AVEC SUCCES<br>';

//ajouter un administrateur par defaut dans la table connexion2 pour inscrire d autres admins et users
$query=mysql_query("INSERT INTO connexion2() VALUES ('','administrateur','administrateur','admin@yahoo.fr') ");
if($query)
echo'REQUETE EFFECTUEE AVEC SUCCES<br>';

$query=mysql_query("");
if($query)
echo'REQUETE EFFECTUEE AVEC SUCCES<br>';

$query=mysql_query("");
if($query)
echo'REQUETE EFFECTUEE AVEC SUCCES<br>';

//ajouter un administrateur par defaut dans la table connexion2 pour inscrire d autres admins et users
?>